import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';

// ── Types ──────────────────────────────────────────────────────────────────

export type LevelId = 'A1' | 'A2' | 'B1' | 'B2' | 'C1' | 'C2';

export interface Lesson {
  id: string;
  title: string;
  titleDe: string;
  description: string;
  content: string;
  examples: string[];
  level: LevelId;
  category: 'grammaire' | 'vocabulaire' | 'prononciation' | 'culture';
  completed: boolean;
}

export interface Exercise {
  id: string;
  question: string;
  questionDe?: string;
  options: string[];
  correctIndex: number;
  explanation: string;
  level: LevelId;
  lessonId: string;
}

export interface Progress {
  [lessonId: string]: {
    completed: boolean;
    score: number;
    attempts: number;
  };
}

// ── Level Colors ───────────────────────────────────────────────────────────

export const LEVEL_COLORS: Record<LevelId, { bg: string; border: string; text: string; glow: string }> = {
  A1: { bg: 'bg-emerald-500/15', border: 'border-emerald-400', text: 'text-emerald-400', glow: 'glow-emerald' },
  A2: { bg: 'bg-blue-500/15', border: 'border-blue-400', text: 'text-blue-400', glow: '' },
  B1: { bg: 'bg-cyan-500/15', border: 'border-cyan-400', text: 'text-cyan-400', glow: 'glow-cyan' },
  B2: { bg: 'bg-amber-500/15', border: 'border-amber-400', text: 'text-amber-400', glow: 'glow-amber' },
  C1: { bg: 'bg-violet-500/15', border: 'border-violet-400', text: 'text-violet-400', glow: 'glow-violet' },
  C2: { bg: 'bg-rose-500/15', border: 'border-rose-400', text: 'text-rose-400', glow: 'glow-rose' },
};

export const LEVEL_NAMES: Record<LevelId, { fr: string; de: string; desc: string }> = {
  A1: { fr: 'Débutant', de: 'Anfänger', desc: 'Les bases — salutations, présentations, nombres' },
  A2: { fr: 'Élémentaire', de: 'Grundstufe', desc: 'Conversations simples, quotidien, voyages' },
  B1: { fr: 'Intermédiaire', de: 'Mittelstufe', desc: 'Opinions, expériences, situations courantes' },
  B2: { fr: 'Avancé', de: 'Fortgeschritten', desc: 'Débats, textes complexes, expression fluide' },
  C1: { fr: 'Autonome', de: 'Selbstständig', desc: 'Nuances, style, compréhension approfondie' },
  C2: { fr: 'Maîtrise', de: 'Meisterschaft', desc: 'Niveau natif, subtilités, expression parfaite' },
};

// ── Lessons Data ───────────────────────────────────────────────────────────

export const LESSONS: Lesson[] = [
  // ═══════════════════════ A1 ═══════════════════════
  { id: 'a1-01', title: 'Se présenter', titleDe: 'Sich vorstellen', description: 'Apprenez à vous présenter en allemand : dire votre nom, votre âge et votre nationalité.', content: `La présentation est la première étape pour communiquer en allemand.\n\n**Ich heiße...** — Je m'appelle...\n**Ich bin...** — Je suis...\n**Wie heißen Sie?** — Comment vous appelez-vous ? (formel)\n**Wie heißt du?** — Comment tu t'appelles ? (informel)\n**Ich komme aus...** — Je viens de...\n**Wie alt bist du?** — Quel âge as-tu ?\n\n**Exemple :**\n— Hallo! Ich heiße Marie. Wie heißt du?\n— Hallo! Ich heiße Jean. Freut mich!`, examples: ['Ich heiße Marie und bin 25 Jahre alt.', 'Ich komme aus Frankreich.', 'Wie heißen Sie? — Ich heiße Dupont.'], level: 'A1', category: 'vocabulaire', completed: false },
  { id: 'a1-02', title: 'Les verbes "sein" et "haben"', titleDe: 'Die Verben "sein" und "haben"', description: 'Les deux verbes les plus importants de l\'allemand : être et avoir, au présent.', content: `**sein** (être) et **haben** (avoir) sont irréguliers et servent aussi d'auxiliaires.\n\n**sein :** ich bin, du bist, er/sie/es ist, wir sind, ihr seid, sie/Sie sind\n**haben :** ich habe, du hast, er/sie/es hat, wir haben, ihr habt, sie/Sie haben\n\n**Exemples :**\n- Ich bin Student. Ich habe einen Bruder.\n- Wir sind aus Paris. Wir haben ein Auto.`, examples: ['Ich bin Marie und ich habe zwei Kinder.', 'Du bist nett und du hast recht.', 'Wir sind Freunde.'], level: 'A1', category: 'grammaire', completed: false },
  { id: 'a1-03', title: 'Les nombres de 1 à 100', titleDe: 'Die Zahlen von 1 bis 100', description: 'Maîtrisez les nombres en allemand pour les situations quotidiennes.', content: `**1-12 :** eins, zwei, drei, vier, fünf, sechs, sieben, acht, neun, zehn, elf, zwölf\n**Dizaines :** zwanzig (20), dreißig (30), vierzig (40), fünfzig (50)...\n\n**Règle :** les unités viennent AVANT les dizaines !\n- 21 = einundzwanzig\n- 35 = fünfunddreißig`, examples: ['Ich bin 25 Jahre alt — fünfundzwanzig.', 'Das kostet 47 Euro — siebenundvierzig.'], level: 'A1', category: 'vocabulaire', completed: false },
  { id: 'a1-04', title: 'Les articles et le genre', titleDe: 'Artikel und grammatisches Geschlecht', description: 'Comprendre der, die, das (articles définis) et ein, eine, kein (indéfinis).', content: `Chaque nom allemand a un genre : masculin (der), féminin (die) ou neutre (das).\n\n**Définis :** der Mann, die Frau, das Kind — pluriel : die\n**Indéfinis :** ein Mann / ein Kind, eine Frau\n**Négation :** keinen Bruder (masc.), keine Schwester (fém.)`, examples: ['Der Tisch ist groß.', 'Die Blumen sind schön.', 'Das Haus ist neu.'], level: 'A1', category: 'grammaire', completed: false },
  { id: 'a1-05', title: 'Le présent des verbes réguliers', titleDe: 'Das Präsens', description: 'Conjuguer les verbes réguliers au présent.', content: `**Terminaisons (machen) :** ich mache, du machst, er/sie/es macht, wir machen, ihr macht, sie/Sie machen\n\n**Verbes à changement de voyelle :**\n- fahren → du fährst, er fährt\n- sehen → du siehst, er sieht\n\n**Règle :** le verbe conjugué est toujours en 2e position.`, examples: ['Ich lerne Deutsch.', 'Er fährt jeden Tag mit dem Bus.', 'Heute lerne ich Deutsch.'], level: 'A1', category: 'grammaire', completed: false },
  { id: 'a1-06', title: 'Salutations et se situer', titleDe: 'Begrüßen und sich orientieren', description: 'Les salutations essentielles et les questions Wo? / Woher?', content: `**Salutations :** Hallo, Guten Morgen/Tag/Abend, Tschüss, Auf Wiedersehen\n**Politesse :** Bitte, Danke (schön), Entschuldigung\n\n**Se situer :**\n- Wo wohnst du? → Ich wohne in Berlin. (position)\n- Woher kommst du? → Ich komme aus Frankreich. (origine)`, examples: ['Guten Morgen, Herr Schmidt!', 'Wo wohnst du? — In München.', 'Ich komme aus Paris.'], level: 'A1', category: 'vocabulaire', completed: false },
  // A2
  { id: 'a2-01', title: 'Le Perfekt', titleDe: 'Das Perfekt', description: 'Le temps du passé le plus utilisé à l\'oral.', content: `**Formation :** haben/sein (présent) + Partizip II (fin de phrase)\n\n**Auxiliaire :**\n- Plupart des verbes → **haben** : Ich habe gegessen.\n- Verbes de mouvement → **sein** : Ich bin gegangen.\n\n**Partizip II :** ge + radical + t (réguliers) ou ge + radical modifié + en (irréguliers)`, examples: ['Ich habe gestern einen Brief geschrieben.', 'Sie ist nach Köln gefahren.', 'Wir haben zusammen gegessen.'], level: 'A2', category: 'grammaire', completed: false },
  { id: 'a2-02', title: 'L\'accusatif et le datif', titleDe: 'Akkusativ und Dativ', description: 'Les deux cas essentiels du quotidien.', content: `**Déclinaison :** nominatif → accusatif → datif\n- masculin : der → den → dem\n- féminin : die → die → der\n- neutre : das → das → dem\n\n**Prépositions accusatif :** für, ohne, durch, um, gegen\n**Prépositions datif :** mit, bei, nach, von, zu, aus`, examples: ['Ich sehe den Mann. (accusatif)', 'Ich helfe dem Mann. (datif)', 'Mit dem Bus zu ihrer Freundin.'], level: 'A2', category: 'grammaire', completed: false },
  { id: 'a2-03', title: 'Les verbes de modalité', titleDe: 'Die Modalverben', description: 'können, müssen, wollen, dürfen — exprimer capacité et obligation.', content: `**Structure :** sujet + verbe modal (2e position) + ... + infinitif (fin)\n\n| | können | müssen | wollen | dürfen |\n|--|---|---|---|---|\n| ich | kann | muss | will | darf |\n| du | kannst | musst | willst | darfst |`, examples: ['Ich kann schwimmen.', 'Du musst deine Hausaufgaben machen.', 'Darf ich das Fenster öffnen?'], level: 'A2', category: 'grammaire', completed: false },
  { id: 'a2-04', title: 'Au restaurant et au magasin', titleDe: 'Im Restaurant und im Geschäft', description: 'Vocabulaire pour commander et faire ses courses.', content: `**Restaurant :** Einen Tisch für zwei, bitte. / Ich möchte... / Die Rechnung, bitte!\n**Magasin :** Ich suche... / Wie viel kostet das? / Ich nehme es.\n\n**Repas :** das Frühstück, das Mittagessen, das Abendessen`, examples: ['Ich hätte gern ein Schnitzel.', 'Das kostet 39 Euro.', 'Zahlen, bitte!'], level: 'A2', category: 'vocabulaire', completed: false },
  { id: 'a2-05', title: 'Les adverbes de temps', titleDe: 'Zeitadverbien', description: 'Exprimer le temps en allemand.', content: `**Passé :** gestern, vorgestern, letzte Woche\n**Présent :** heute, jetzt, gerade\n**Futur :** morgen, übermorgen, nächste Woche, bald\n\n**Position :** l'adverbe en 1re position envoie le sujet en 3e.`, examples: ['Heute ist Montag.', 'Ich komme morgen um 8 Uhr.', 'Gestern habe ich gelernt.'], level: 'A2', category: 'vocabulaire', completed: false },
  { id: 'a2-06', title: 'Le comparatif et superlatif', titleDe: 'Komparativ und Superlativ', description: 'Comparer des choses en allemand.', content: `**Comparatif :** adjectif + -er + als → schneller als\n**Superlatif :** am + adjectif + -sten → am schnellsten\n\n**Irréguliers :** gut → besser → am besten / viel → mehr → am meisten`, examples: ['Berlin ist größer als München.', 'Das ist der beste Film.', 'Ich esse am liebsten Pizza.'], level: 'A2', category: 'grammaire', completed: false },
  // B1
  { id: 'b1-01', title: 'Le Präteritum', titleDe: 'Das Präteritum', description: 'Le temps du passé à l\'écrit.', content: `**Réguliers :** radical + -te → ich machte, du machtest\n\n**Irréguliers clés :**\n- sein → war / haben → hatte / gehen → ging / kommen → kam\n\n**Usage :** surtout à l'écrit ; sein/haben restent courants même à l'oral.`, examples: ['Ich ging ins Kino, es war sehr spannend.', 'Es regnete den ganzen Tag.', 'Wir hatten viel Spaß.'], level: 'B1', category: 'grammaire', completed: false },
  { id: 'b1-02', title: 'Les pronoms relatifs', titleDe: 'Relativpronomen', description: 'Construire des phrases complexes.', content: `Les pronoms relatifs s'accordent en genre/nombre avec le nom antécédent.\n\n| Cas | Masc. | Fém. | Neutre | Pluriel |\n|--|--|--|--|--|\n| Nom. | der | die | das | die |\n| Acc. | den | die | das | die |\n| Dat. | dem | der | dem | denen |\n| Gén. | dessen | deren | dessen | deren |`, examples: ['Der Mann, der dort steht, ist mein Vater.', 'Die Stadt, in der ich wohne, ist schön.', 'Der Mann, dessen Auto gestohlen wurde.'], level: 'B1', category: 'grammaire', completed: false },
  { id: 'b1-03', title: 'Le Konjunktiv II', titleDe: 'Der Konjunktiv II', description: 'Exprimer l\'hypothèse, le souhait et la politesse.', content: `**Formes essentielles :** sein → wäre / haben → hätte / werden → würde / können → könnte\n\n**Utilisations :**\n1. Condition irréelle : Wenn ich reich wäre, würde ich reisen.\n2. Politesse : Könnten Sie mir helfen?`, examples: ['Wenn ich Zeit hätte, würde ich lernen.', 'Könnten Sie das bitte wiederholen?', 'Ich wünschte, ich wäre in Berlin.'], level: 'B1', category: 'grammaire', completed: false },
  { id: 'b1-04', title: 'Les prépositions à double sens', titleDe: 'Wechselpräpositionen', description: 'an, auf, in... : accusatif pour le mouvement, datif pour la position.', content: `**Règle :** Wohin? (mouvement) → accusatif / Wo? (position) → datif\n\n- Ich gehe in die Schule. (acc.) ↔ Ich bin in der Schule. (dat.)\n- Er legt das Buch auf den Tisch. (acc.) ↔ Das Buch liegt auf dem Tisch. (dat.)`, examples: ['Ich stelle die Vase auf den Tisch.', 'Die Vase steht auf dem Tisch.', 'Er geht ins Kino.'], level: 'B1', category: 'grammaire', completed: false },
  { id: 'b1-05', title: 'La déclinaison des adjectifs', titleDe: 'Die Adjektivdeklination', description: 'Accorder l\'adjectif épithète.', content: `**Après article défini (faible) :** der kleine Mann, die kleine Frau\n**Après article indéfini (mixte) :** ein kleiner Mann, eine kleine Frau\n**Sans article (forte) :** kleiner Mann, kleine Frau`, examples: ['Der große Hund bellt laut.', 'Ich habe einen kleinen Bruder.', 'Frisches Brot riecht gut.'], level: 'B1', category: 'grammaire', completed: false },
  { id: 'b1-06', title: 'La voix passive', titleDe: 'Das Passiv', description: 'Construire et utiliser la voix passive.', content: `**Formation :** werden + Partizip II\n- Präsens : Das Haus wird gebaut.\n- Präteritum : Das Haus wurde gebaut.\n\n**Passif impersonnel :** Hier wird nicht geraucht.`, examples: ['Das Haus wird gebaut.', 'Deutsch wird weltweit gesprochen.', 'Die Prüfung wurde gestern geschrieben.'], level: 'B1', category: 'grammaire', completed: false },
  // B2
  { id: 'b2-01', title: 'Le Konjunktiv I', titleDe: 'Der Konjunktiv I', description: 'Le discours indirect.', content: `Le **Konjunktiv I** est utilisé dans le discours indirect (presse, littérature).\n\n**sein au KI :** ich sei, er/sie/es sei, wir seien\n\n**Exemple :**\n- "Ich bin müde." → Er sagt, er **sei** müde.`, examples: ['Er behauptete, er habe das nicht gewusst.', 'Die Zeitung schreibt, Preise würden steigen.', 'Sie sagte, sie komme morgen.'], level: 'B2', category: 'grammaire', completed: false },
  { id: 'b2-02', title: 'Les verbes à particule séparable', titleDe: 'Trennbare Verben', description: 'Maîtriser les verbes avec préfixe séparable.', content: `**Exemples :** aufstehen → ich stehe auf / anfangen → es fängt an\n\n**Regel :** le préfixe va en fin de phrase principale.\n**Partizip II :** ge- entre préfixe et radical → aufgestanden\n\n**Inséparables :** be-, ver-, er-, ent-...`, examples: ['Ich stehe jeden Morgen um 6 auf.', 'Der Unterricht fängt um 9 Uhr an.'], level: 'B2', category: 'grammaire', completed: false },
  { id: 'b2-03', title: 'Les connecteurs logiques', titleDe: 'Logische Verbindungswörter', description: 'Structurer un discours avec des connecteurs avancés.', content: `**Cause :** weil, da, aufgrund von\n**Conséquence :** deshalb, deswegen, sodass\n**Opposition :** obwohl, trotzdem, allerdings\n**Addition :** außerdem, darüber hinaus, nicht nur... sondern auch`, examples: ['Obwohl es regnete, gingen wir spazieren.', 'Nicht nur der Preis, sondern auch die Qualität ist wichtig.'], level: 'B2', category: 'grammaire', completed: false },
  { id: 'b2-04', title: 'L\'argumentation', titleDe: 'Die Argumentation', description: 'Construire une argumentation solide.', content: `**Structure :** Einleitung → Pro → Contra → Eigene Meinung → Schluss\n\n**Phrases utiles :**\n- Ein Vorteil ist... / Dagegen spricht, dass...\n- Zusammenfassend lässt sich sagen, dass...`, examples: ['Ein Vorteil von Homeschooling ist individuelle Förderung.', 'Zusammenfassend haben beide Seiten ihre Berechtigung.'], level: 'B2', category: 'vocabulaire', completed: false },
  { id: 'b2-05', title: 'Passif avec modaux', titleDe: 'Passiv mit Modalverben', description: 'Combiner passif et verbe de modalité.', content: `**Formation :** verbe modal + ... + Partizip II + werden\n\n- Die Hausaufgaben müssen gemacht werden.\n- Das Auto kann repariert werden.`, examples: ['Die Regeln müssen respektiert werden.', 'Das Problem konnte schnell gelöst werden.'], level: 'B2', category: 'grammaire', completed: false },
  { id: 'b2-06', title: 'Opinion nuancée', titleDe: 'Eine differenzierte Meinung äußern', description: 'Nuancer et défendre son point de vue.', content: `**Nuancer :** Einerseits..., andererseits... / Es kommt darauf an, ob...\n**Objecter :** Man könnte einwenden, dass... / Zwar..., aber...\n**Renforcer :** Es steht außer Frage, dass...`, examples: ['Einerseits spart man Zeit, andererseits verliert man Kontakt.', 'Zwar ist die Idee gut, aber schwer umzusetzen.'], level: 'B2', category: 'vocabulaire', completed: false },
  // C1
  { id: 'c1-01', title: 'Les constructions nominales', titleDe: 'Nominalisierung', description: 'Transformer des propositions verbales en constructions nominales.', content: `**Principe :** verbes → noms, conjonctions → prépositions\n\n- Weil die Preise steigen → Wegen des Preisanstiegs\n- Wenn man verschmutzt → Bei der Verschmutzung`, examples: ['Durch die Digitalisierung verändern sich Arbeitsplätze.', 'Während des Studiums wohnte ich in München.'], level: 'C1', category: 'grammaire', completed: false },
  { id: 'c1-02', title: 'Le style académique', titleDe: 'Der akademische Stil', description: 'Écrire dans un style formel et académique.', content: `**Connecteurs :** Demzufolge, Im Hinblick auf, Folglich, Ungeachtet dessen\n\n**Introduction :** Die vorliegende Arbeit untersucht...\n**Conclusion :** Zusammenfassend lässt sich feststellen, dass...`, examples: ['Im Hinblick auf die Digitalisierung...', 'Die vorliegende Studie untersucht die Auswirkungen.'], level: 'C1', category: 'vocabulaire', completed: false },
  { id: 'c1-03', title: 'Les idiomatismes avancés', titleDe: 'Fortgeschrittene Redewendungen', description: 'Expressions idiomatiques en allemand.', content: `- **Ich verstehe nur Bahnhof.** — Je n'y comprends rien.\n- **Das ist nicht mein Bier.** — Ce n'est pas mon problème.\n- **Schwein haben.** — Avoir de la chance.\n- **Ins kalte Wasser springen.** — Se jeter à l'eau.`, examples: ['Das ist nicht mein Bier — ich habe damit nichts zu tun.', 'Er hat Schwein gehabt und bestanden.'], level: 'C1', category: 'vocabulaire', completed: false },
  { id: 'c1-04', title: 'Prépositions causales avancées', titleDe: 'Fortgeschrittene Kausalpräpositionen', description: 'Nuancer la cause avec wegen, dank, aufgrund, angesichts.', content: `- **wegen** (neutre) : Wegen des Staus kam ich zu spät.\n- **dank** (positif) : Dank deiner Hilfe habe ich bestanden.\n- **aufgrund** (factuel) : Aufgrund der Ergebnisse...\n- **angesichts** (face à) : Angesichts der Lage...`, examples: ['Dank seiner Geduld hat er das Problem gelöst.', 'Aufgrund technischer Probleme fällt der Unterricht aus.'], level: 'C1', category: 'grammaire', completed: false },
  { id: 'c1-05', title: 'Médias et société', titleDe: 'Medien und Gesellschaft', description: 'Vocabulaire pour discuter des médias et des enjeux de société.', content: `**Médias :** die Berichterstattung, die Meinungsfreiheit, die Fake News, die Medienkompetenz\n**Société :** der gesellschaftliche Wandel, die Chancengleichheit, der Zusammenhalt`, examples: ['Die Medienkompetenz der Jugend nimmt zu.', 'Es lässt sich nicht leugnen, dass Medien die Debatte verändern.'], level: 'C1', category: 'vocabulaire', completed: false },
  { id: 'c1-06', title: 'La cohérence textuelle', titleDe: 'Textkohärenz', description: 'Lier les idées d\'un texte long de façon fluide.', content: `**Anaphores :** dieser/diese/dieses, jener, derselbe, ersterer/letzterer\n**Connecteurs :** Zunächst..., anschließend..., schließlich... / Diesbezüglich / In diesem Zusammenhang`, examples: ['Diesbezüglich gibt es unterschiedliche Meinungen.', 'In diesem Zusammenhang spielt Bildung eine zentrale Rolle.'], level: 'C1', category: 'grammaire', completed: false },
  // C2
  { id: 'c2-01', title: 'La rhétorique allemande', titleDe: 'Die deutsche Rhetorik', description: 'Maîtriser l\'art oratoire et les techniques rhétoriques.', content: `**Figures :** Antithèse, Klimax (gradation), Litotes, Anapher, Question rhétorique\n\n**Techniques :** Pathos (émotion), Ethos (crédibilité), Logos (logique)`, examples: ['Nicht nur die Tat zählt, sondern auch die Absicht.', 'Wer wagt, gewinnt.'], level: 'C2', category: 'culture', completed: false },
  { id: 'c2-02', title: 'Les nuances linguistiques', titleDe: 'Sprachliche Nuancen', description: 'Les subtilités qui distinguent un locuteur avancé.', content: `**Registres :** Umgangssprache, Alltagssprache, Bildungssprache, Fachsprache\n\n**Modalpartikeln :** doch, halt, mal, wohl, ja — changent entièrement le ton.\n- "Das ist ja unglaublich!" (surprise)\n- "Komm doch mal vorbei!" (invitation)`, examples: ['Das ist ja unglaublich!', 'Er hat wohl den Zug verpasst. (supposition)'], level: 'C2', category: 'culture', completed: false },
  { id: 'c2-03', title: 'L\'humour et l\'ironie', titleDe: 'Humor und Ironie', description: 'Comprendre et utiliser l\'humour et le sarcasme.', content: `**Types :** Trockener Humor, Selbstironie, Wortspiel, Übertreibung\n\n**Repérer l'ironie :** ton, contexte, mots comme "wirklich", "ja natürlich"`, examples: ['"Das hast du ja super gemacht!" — ironie.', '"Tolles Wetter!" — dit sous la pluie.'], level: 'C2', category: 'culture', completed: false },
  { id: 'c2-04', title: 'Le style littéraire', titleDe: 'Der literarische Stil', description: 'Reconnaître et analyser les registres stylistiques.', content: `**Caractéristiques :** inversions poétiques, métaphores filées, phrases nominales\n\n**Analyser :** Erzählperspektive, rythme des phrases, figures de style (Metapher, Symbol, Ellipse).`, examples: ['La ville dormait, tandis que la pluie tombait sans cesse.', 'Stille. Dunkelheit. Nichts.'], level: 'C2', category: 'culture', completed: false },
  { id: 'c2-05', title: 'Allemand académique', titleDe: 'Wissenschaftsdeutsch', description: 'Le registre des publications scientifiques.', content: `**Structures :** Es lässt sich beobachten, dass... / Die Daten deuten darauf hin, dass...\n**Vocabulaire :** die Hypothese, die Methodik, die Signifikanz, die Stichprobe\n**Prudence :** "es scheint", "tendenziell"`, examples: ['Die Ergebnisse deuten tendenziell auf einen Zusammenhang hin.', 'Weitere Forschung ist notwendig.'], level: 'C2', category: 'vocabulaire', completed: false },
  { id: 'c2-06', title: 'L\'intraduisible', titleDe: 'Das Unübersetzbare', description: 'Les mots allemands sans équivalent direct en français.', content: `- **Fernweh** — le mal du lointain\n- **Feierabend** — la fin de la journée de travail\n- **Geborgenheit** — sentiment de sécurité affective\n- **Verschlimmbessern** — aggraver en voulant améliorer`, examples: ['Er hat großes Fernweh und will die Welt bereisen.', 'Nach Feierabend trifft er Freunde.'], level: 'C2', category: 'culture', completed: false },
];

// ── Exercises Data ────────────────────────────────────────────────────────

export const EXERCISES: Exercise[] = [
  // A1
  { id: 'a1-01-e1', question: 'Comment dit-on "Je m\'appelle Marie" en allemand ?', options: ['Ich bin Marie', 'Ich heiße Marie', 'Ich komme Marie', 'Ich habe Marie'], correctIndex: 1, explanation: '"Ich heiße..." est la formule standard pour se présenter.', level: 'A1', lessonId: 'a1-01' },
  { id: 'a1-01-e2', question: '"Wie heißen Sie?" est utilisé dans quel registre ?', options: ['Familier', 'Formel', 'Les deux', 'Aucun'], correctIndex: 1, explanation: '"Sie" (majuscule) indique le vouvoiement, registre formel.', level: 'A1', lessonId: 'a1-01' },
  { id: 'a1-02-e1', question: 'Conjuguez "haben" à la 1ère personne du singulier :', options: ['bin', 'habe', 'hast', 'hat'], correctIndex: 1, explanation: 'ich habe — j\'ai.', level: 'A1', lessonId: 'a1-02' },
  { id: 'a1-02-e2', question: 'Complétez : "Wir ___ aus Paris."', options: ['bin', 'bist', 'ist', 'sind'], correctIndex: 3, explanation: 'wir sind — nous sommes.', level: 'A1', lessonId: 'a1-02' },
  { id: 'a1-03-e1', question: 'Comment dit-on "vingt-cinq" en allemand ?', options: ['fünfzwanzig', 'fünfundzwanzig', 'zwanzigfünf', 'fünf von zwanzig'], correctIndex: 1, explanation: 'En allemand, les unités viennent AVANT les dizaines.', level: 'A1', lessonId: 'a1-03' },
  { id: 'a1-04-e1', question: 'Quel est l\'article défini de "Mann" (homme) ?', options: ['die', 'das', 'der', 'den'], correctIndex: 2, explanation: 'der Mann — masculin au nominatif.', level: 'A1', lessonId: 'a1-04' },
  { id: 'a1-05-e1', question: 'Conjuguez "fahren" à "du" :', options: ['fahrst', 'fährst', 'fahrest', 'fahren'], correctIndex: 1, explanation: 'fahren change de voyelle : du fährst.', level: 'A1', lessonId: 'a1-05' },
  { id: 'a1-06-e1', question: 'Comment dit-on "Merci beaucoup" ?', options: ['Bitte schön', 'Danke schön', 'Entschuldigung', 'Guten Tag'], correctIndex: 1, explanation: '"Danke schön" signifie "Merci beaucoup".', level: 'A1', lessonId: 'a1-06' },
  // A2
  { id: 'a2-01-e1', question: 'Quel auxiliaire avec "gehen" au Perfekt ?', options: ['haben', 'sein', 'werden', 'les deux'], correctIndex: 1, explanation: 'Les verbes de mouvement utilisent "sein".', level: 'A2', lessonId: 'a2-01' },
  { id: 'a2-01-e2', question: 'Quel est le Partizip II de "essen" ?', options: ['geesst', 'gegessen', 'gesst', 'essen'], correctIndex: 1, explanation: 'essen → gegessen (irrégulier).', level: 'A2', lessonId: 'a2-01' },
  { id: 'a2-02-e1', question: '"Ich sehe ___ Mann." — quel article ?', options: ['der (nom.)', 'den (acc.)', 'dem (dat.)', 'des (gén.)'], correctIndex: 1, explanation: 'COD → accusatif : den Mann.', level: 'A2', lessonId: 'a2-02' },
  { id: 'a2-03-e1', question: 'Complétez : "Ich ___ gut Deutsch sprechen."', options: ['muss', 'kann', 'will', 'darf'], correctIndex: 1, explanation: '"können" exprime la capacité.', level: 'A2', lessonId: 'a2-03' },
  { id: 'a2-04-e1', question: 'Comment demander l\'addition ?', options: ['Die Speisekarte, bitte.', 'Die Rechnung, bitte.', 'Das Essen, bitte.', 'Das Geld, bitte.'], correctIndex: 1, explanation: '"Die Rechnung, bitte" = l\'addition.', level: 'A2', lessonId: 'a2-04' },
  { id: 'a2-05-e1', question: 'Comment dit-on "avant-hier" ?', options: ['morgen', 'gestern', 'vorgestern', 'übermorgen'], correctIndex: 2, explanation: 'vorgestern = avant-hier.', level: 'A2', lessonId: 'a2-05' },
  { id: 'a2-06-e1', question: 'Quel est le comparatif de "gut" ?', options: ['guter', 'gutter', 'besser', 'mehr gut'], correctIndex: 2, explanation: '"gut" a une forme irrégulière : besser.', level: 'A2', lessonId: 'a2-06' },
  // B1
  { id: 'b1-01-e1', question: 'Präteritum de "gehen" à la 1ère personne ?', options: ['gehete', 'ging', 'ginge', 'gegangte'], correctIndex: 1, explanation: 'gehen → ging (irrégulier).', level: 'B1', lessonId: 'b1-01' },
  { id: 'b1-02-e1', question: '"Die Frau, ___ ich gesehen habe..." ?', options: ['der', 'die', 'das', 'denen'], correctIndex: 1, explanation: 'Die Frau (féminin, accusatif) → die.', level: 'B1', lessonId: 'b1-02' },
  { id: 'b1-03-e1', question: '"Wenn ich reich wäre..." — quel mode ?', options: ['Präsens', 'Präteritum', 'Konjunktiv II', 'Konjunktiv I'], correctIndex: 2, explanation: '"wäre" est le Konjunktiv II de "sein".', level: 'B1', lessonId: 'b1-03' },
  { id: 'b1-04-e1', question: '"Ich gehe ___ die Schule." (mouvement) — quel cas ?', options: ['nominatif', 'accusatif', 'datif', 'génitif'], correctIndex: 1, explanation: 'Mouvement → accusatif.', level: 'B1', lessonId: 'b1-04' },
  { id: 'b1-05-e1', question: '"der klein___ Mann" (déf., nominatif) ?', options: ['-e', '-er', '-es', '-en'], correctIndex: 0, explanation: 'Après article défini au nominatif, terminaison faible -e.', level: 'B1', lessonId: 'b1-05' },
  { id: 'b1-06-e1', question: '"Der Mann ___ gebissen." (passif présent) ?', options: ['wird', 'ist', 'hat', 'war'], correctIndex: 0, explanation: 'Passif Präsens : wird + Partizip II.', level: 'B1', lessonId: 'b1-06' },
  // B2
  { id: 'b2-01-e1', question: '"Er sagt, er ___ müde." (Konjunktiv I) ?', options: ['ist', 'sei', 'wäre', 'bin'], correctIndex: 1, explanation: 'Konjunktiv I de "sein" → sei.', level: 'B2', lessonId: 'b2-01' },
  { id: 'b2-02-e1', question: '"Ich ___ um 7 Uhr ___." (aufstehen) ?', options: ['stehe... auf', 'aufstehe', 'stehe auf', 'auf stehe'], correctIndex: 0, explanation: 'Verbe séparable : préfixe à la fin.', level: 'B2', lessonId: 'b2-02' },
  { id: 'b2-03-e1', question: '"___ es regnete, gingen wir spazieren." ?', options: ['Weil', 'Obwohl', 'Deshalb', 'Sondern'], correctIndex: 1, explanation: '"Obwohl" = "bien que".', level: 'B2', lessonId: 'b2-03' },
  { id: 'b2-05-e1', question: '"Die Hausaufgaben müssen bis morgen ___." ?', options: ['gemacht werden', 'werden gemacht', 'machen werden', 'gemacht sein'], correctIndex: 0, explanation: 'Passif + modal : Partizip II + werden.', level: 'B2', lessonId: 'b2-05' },
  // C1
  { id: 'c1-01-e1', question: '"___ der Digitalisierung verändern sich Arbeitsplätze." ?', options: ['Wegen', 'Durch', 'Trotz', 'Statt'], correctIndex: 1, explanation: '"Durch" + Akkusativ exprime le moyen.', level: 'C1', lessonId: 'c1-01' },
  { id: 'c1-02-e1', question: 'Expression typique du style académique ?', options: ['Das ist cool!', 'Im Hinblick auf...', 'Ich mag das.', 'Toll gemacht!'], correctIndex: 1, explanation: '"Im Hinblick auf..." est une expression formelle.', level: 'C1', lessonId: 'c1-02' },
  { id: 'c1-03-e1', question: 'Que signifie "Ich verstehe nur Bahnhof" ?', options: ['Je comprends tout', 'Je n\'y comprends rien', 'Je vais à la gare', 'Je parle allemand'], correctIndex: 1, explanation: 'Idiomatisme : "Je n\'y comprends rien".', level: 'C1', lessonId: 'c1-03' },
  // C2
  { id: 'c2-01-e1', question: 'Figure rhétorique de "Wer wagt, gewinnt" ?', options: ['Metapher', 'Klimax', 'Antithèse', 'Alliteration'], correctIndex: 3, explanation: '"Wer wagt, gewinnt" utilise l\'allitération (w).', level: 'C2', lessonId: 'c2-01' },
  { id: 'c2-02-e1', question: 'Quelle Modalpartikel exprime la résignation ?', options: ['doch', 'halt', 'mal', 'ja'], correctIndex: 1, explanation: '"halt" exprime la résignation : "Das ist halt so."', level: 'C2', lessonId: 'c2-02' },
  { id: 'c2-06-e1', question: 'Que signifie "Feierabend" ?', options: ['Un jour férié', 'La fin de la journée de travail', 'Une fête', 'Le matin'], correctIndex: 1, explanation: '"Feierabend" = le moment où le travail se termine.', level: 'C2', lessonId: 'c2-06' },
];

// ── AI Practice Scenarios ─────────────────────────────────────────────────

export interface AIScenario {
  id: string;
  title: string;
  titleDe: string;
  description: string;
  level: LevelId;
  context: string;
  initialMessage: string;
  tips: string[];
  vocabulary: { de: string; fr: string }[];
}

export const AI_SCENARIOS: AIScenario[] = [
  { id: 'a1-cafe', title: 'Au café', titleDe: 'Im Café', description: 'Commandez un café et un gâteau dans un café berlinois.', level: 'A1', context: 'Vous êtes dans un café à Berlin.', initialMessage: 'Hallo! Willkommen im Café Berlin. Was möchten Sie bestellen?', tips: ['Utilisez "Ich hätte gern..."', 'Demandez le prix avec "Was kostet das?"', 'Remerciez avec "Danke schön"'], vocabulary: [{ de: 'der Kaffee', fr: 'le café' }, { de: 'der Kuchen', fr: 'le gâteau' }, { de: 'das Wasser', fr: 'l\'eau' }, { de: 'die Rechnung', fr: 'l\'addition' }] },
  { id: 'a1-familie', title: 'Présenter sa famille', titleDe: 'Die Familie vorstellen', description: 'Parlez de votre famille à un nouvel ami allemand.', level: 'A1', context: 'Vous rencontrez un Allemand pour la première fois.', initialMessage: 'Hallo! Ich heiße Klaus. Und du? Hast du Geschwister?', tips: ['Utilisez "Ich habe..." pour parler de votre famille', 'Décrivez avec des adjectifs simples', 'Posez des questions avec "Hast du...?"'], vocabulary: [{ de: 'die Mutter', fr: 'la mère' }, { de: 'der Vater', fr: 'le père' }, { de: 'das Geschwister', fr: 'frère/sœur' }, { de: 'die Familie', fr: 'la famille' }] },
  { id: 'a2-bahnhof', title: 'À la gare', titleDe: 'Am Bahnhof', description: 'Achetez un billet et demandez des informations.', level: 'A2', context: 'Vous êtes à la gare centrale de Munich.', initialMessage: 'Guten Tag! Möchten Sie ein Ticket kaufen?', tips: ['Utilisez "Ich möchte..."', 'Demandez avec "Wann fährt der Zug...?"', 'Précisez la classe'], vocabulary: [{ de: 'das Ticket', fr: 'le billet' }, { de: 'der Zug', fr: 'le train' }, { de: 'die Abfahrt', fr: 'le départ' }, { de: 'der Bahnsteig', fr: 'le quai' }] },
  { id: 'a2-arzt', title: 'Chez le médecin', titleDe: 'Beim Arzt', description: 'Décrivez vos symptômes au médecin.', level: 'A2', context: 'Vous ne vous sentez pas bien.', initialMessage: 'Guten Tag! Was fehlt Ihnen? Wo tut es weh?', tips: ['Décrivez la douleur : "Es tut weh"', 'Indiquez depuis quand : "seit zwei Tagen"', 'Utilisez "Ich fühle mich..."'], vocabulary: [{ de: 'die Schmerzen', fr: 'les douleurs' }, { de: 'das Fieber', fr: 'la fièvre' }, { de: 'die Erkältung', fr: 'le rhume' }, { de: 'das Rezept', fr: 'l\'ordonnance' }] },
  { id: 'b1-meinung', title: 'Débat : Transports', titleDe: 'Debatte: Öffentliche Verkehrsmittel', description: 'Discutez des transports en commun.', level: 'B1', context: 'Discussion sur les transports publics en Allemagne.', initialMessage: 'Ich denke, dass öffentliche Verkehrsmittel sehr wichtig sind. Was meinen Sie?', tips: ['Exprimez votre opinion : "Meiner Meinung nach..."', 'Utilisez "einerseits... andererseits..."', 'Donnez des exemples concrets'], vocabulary: [{ de: 'die Umwelt', fr: 'l\'environnement' }, { de: 'die Verkehrsmittel', fr: 'les transports' }, { de: 'die Kosten', fr: 'les coûts' }, { de: 'die Bequemlichkeit', fr: 'le confort' }] },
  { id: 'b1-reise', title: 'Planifier un voyage', titleDe: 'Eine Reise planen', description: 'Organisez un voyage en Allemagne.', level: 'B1', context: 'Vous planifiez un voyage en Allemagne.', initialMessage: 'Hey! Ich habe Zeit im August. Wohin möchtest du reisen?', tips: ['Faites des suggestions : "Wir könnten..."', 'Exprimez des préférences : "Ich würde lieber..."', 'Utilisez le Konjunktiv II'], vocabulary: [{ de: 'die Unterkunft', fr: 'l\'hébergement' }, { de: 'die Sehenswürdigkeit', fr: 'le monument' }, { de: 'das Budget', fr: 'le budget' }, { de: 'die Route', fr: 'l\'itinéraire' }] },
  { id: 'b2-jobinterview', title: 'Entretien d\'embauche', titleDe: 'Vorstellungsgespräch', description: 'Passez un entretien pour un poste en Allemagne.', level: 'B2', context: 'Vous postulez pour un poste à Berlin.', initialMessage: 'Guten Tag! Können Sie sich bitte kurz vorstellen?', tips: ['Parlez de votre parcours', 'Montrez votre motivation', 'Utilisez le Konjunktiv I pour les informations'], vocabulary: [{ de: 'die Erfahrung', fr: 'l\'expérience' }, { de: 'die Qualifikation', fr: 'la qualification' }, { de: 'das Gehalt', fr: 'le salaire' }, { de: 'die Teamarbeit', fr: 'le travail d\'équipe' }] },
  { id: 'b2-klimawandel', title: 'Le changement climatique', titleDe: 'Der Klimawandel', description: 'Débattez des solutions au changement climatique.', level: 'B2', context: 'Débat sur les mesures contre le changement climatique.', initialMessage: 'Der Klimawandel ist eine der größten Herausforderungen. Welche Maßnahmen halten Sie für effektiv?', tips: ['Utilisez des connecteurs logiques', 'Argumentez avec des faits', 'Concédez puis contrez : "Zwar..., aber..."'], vocabulary: [{ de: 'die erneuerbare Energie', fr: 'l\'énergie renouvelable' }, { de: 'die CO2-Emission', fr: 'l\'émission de CO2' }, { de: 'die Maßnahme', fr: 'la mesure' }, { de: 'die Nachhaltigkeit', fr: 'la durabilité' }] },
  { id: 'c1-literatur', title: 'Analyse littéraire', titleDe: 'Literarische Analyse', description: 'Analysez un texte de Kafka ou Goethe.', level: 'C1', context: 'Vous discutez avec un professeur de littérature.', initialMessage: 'Haben Sie Kafkas "Die Verwandlung" gelesen? Wie interpretieren Sie die Verwandlung Gregor Samsas?', tips: ['Utilisez des constructions nominales', 'Citez et analysez le texte', 'Comparez avec d\'autres œuvres'], vocabulary: [{ de: 'die Entfremdung', fr: 'l\'aliénation' }, { de: 'die Metapher', fr: 'la métaphore' }, { de: 'das Motiv', fr: 'le motif' }, { de: 'die Interpretation', fr: 'l\'interprétation' }] },
  { id: 'c2-philosophie', title: 'Philosophie allemande', titleDe: 'Deutsche Philosophie', description: 'Débattez de concepts philosophiques.', level: 'C2', context: 'Vous discutez de Kant et Hegel avec un universitaire.', initialMessage: 'Kants kategorischer Imperativ — ist er wirklich universell anwendbar? Wie steht es mit kulturellen Unterschieden?', tips: ['Utilisez des structures complexes', 'Réfutez avec élégance : "Man könnte einwenden, dass..."', 'Synthétisez habilement'], vocabulary: [{ de: 'der kategorische Imperativ', fr: 'l\'impératif catégorique' }, { de: 'die Ethik', fr: 'l\'éthique' }, { de: 'die Maxime', fr: 'la maxime' }, { de: 'die Autonomie', fr: 'l\'autonomie' }] },
];

// ── Sentence Exercises ────────────────────────────────────────────────────

export interface SentenceExercise {
  id: string;
  level: LevelId;
  words: string[];
  translation: string;
  hint?: string;
}

export const SENTENCE_EXERCISES: SentenceExercise[] = [
  { id: 'sb-a1-1', level: 'A1', words: ['Ich', 'heiße', 'Anna', 'und', 'ich', 'komme', 'aus', 'Frankreich.'], translation: 'Je m\'appelle Anna et je viens de France.', hint: 'Le verbe conjugué est toujours en 2e position.' },
  { id: 'sb-a1-2', level: 'A1', words: ['Der', 'Kaffee', 'kostet', 'drei', 'Euro', 'fünfzig.'], translation: 'Le café coûte trois euros cinquante.', hint: 'Sujet + verbe + complément.' },
  { id: 'sb-a1-3', level: 'A1', words: ['Wir', 'wohnen', 'in', 'einer', 'kleinen', 'Wohnung.'], translation: 'Nous habitons dans un petit appartement.', hint: 'L\'adjectif précède toujours le nom.' },
  { id: 'sb-a2-1', level: 'A2', words: ['Gestern', 'bin', 'ich', 'mit', 'dem', 'Zug', 'nach', 'Berlin', 'gefahren.'], translation: 'Hier, je suis allé(e) à Berlin en train.', hint: 'Adverbe en 1re position → sujet après le verbe.' },
  { id: 'sb-a2-2', level: 'A2', words: ['Er', 'hat', 'seine', 'Hausaufgaben', 'noch', 'nicht', 'gemacht.'], translation: 'Il n\'a pas encore fait ses devoirs.', hint: 'Au Perfekt, le participe passé est en toute fin.' },
  { id: 'sb-a2-3', level: 'A2', words: ['Kannst', 'du', 'mir', 'bitte', 'helfen,', 'den', 'Tisch', 'zu', 'tragen?'], translation: 'Peux-tu m\'aider à porter la table ?', hint: 'Question fermée : verbe conjugué en tête.' },
  { id: 'sb-b1-1', level: 'B1', words: ['Wenn', 'ich', 'mehr', 'Zeit', 'hätte,', 'würde', 'ich', 'öfter', 'Sport', 'treiben.'], translation: 'Si j\'avais plus de temps, je ferais du sport plus souvent.', hint: 'Konjunktiv II : verbe conjugué à la fin de la subordonnée.' },
  { id: 'sb-b1-2', level: 'B1', words: ['Die', 'Frau,', 'die', 'neben', 'mir', 'wohnt,', 'ist', 'Lehrerin.'], translation: 'La femme qui habite à côté de moi est enseignante.', hint: 'Dans une relative, le verbe est en toute fin.' },
  { id: 'sb-b1-3', level: 'B1', words: ['Obwohl', 'es', 'geregnet', 'hat,', 'sind', 'wir', 'spazieren', 'gegangen.'], translation: 'Bien qu\'il ait plu, nous sommes allés nous promener.', hint: '"Obwohl" → verbe conjugué à la fin de la subordonnée.' },
  { id: 'sb-b2-1', level: 'B2', words: ['Die', 'Regierung', 'hat', 'beschlossen,', 'die', 'Steuern', 'zu', 'erhöhen.'], translation: 'Le gouvernement a décidé d\'augmenter les impôts.', hint: 'Construction infinitive avec "zu".' },
  { id: 'sb-b2-2', level: 'B2', words: ['Trotz', 'der', 'schwierigen', 'Lage', 'bleibt', 'die', 'Wirtschaft', 'stabil.'], translation: 'Malgré la situation difficile, l\'économie reste stable.', hint: '"Trotz" est suivi du génitif.' },
  { id: 'sb-b2-3', level: 'B2', words: ['Man', 'sollte', 'immer', 'die', 'Konsequenzen', 'seiner', 'Entscheidungen', 'bedenken.'], translation: 'On devrait toujours réfléchir aux conséquences de ses décisions.', hint: 'Verbe modal + infinitif en fin.' },
  { id: 'sb-c1-1', level: 'C1', words: ['Im', 'Hinblick', 'auf', 'die', 'demografische', 'Entwicklung', 'müssen', 'neue', 'Lösungen', 'gefunden', 'werden.'], translation: 'Au vu de l\'évolution démographique, de nouvelles solutions doivent être trouvées.', hint: 'Voix passive avec modal : Partizip II + werden.' },
  { id: 'sb-c1-2', level: 'C1', words: ['Die', 'Digitalisierung', 'verändert', 'nicht', 'nur', 'die', 'Arbeitswelt,', 'sondern', 'auch', 'unser', 'Privatleben.'], translation: 'La numérisation transforme non seulement le monde du travail, mais aussi notre vie privée.', hint: 'Structure corrélative "nicht nur... sondern auch".' },
  { id: 'sb-c1-3', level: 'C1', words: ['Es', 'lässt', 'sich', 'nicht', 'leugnen,', 'dass', 'der', 'Klimawandel', 'drastische', 'Maßnahmen', 'erfordert.'], translation: 'On ne peut nier que le changement climatique exige des mesures drastiques.', hint: 'Subordonnée avec "dass" : verbe conjugué en fin.' },
  { id: 'sb-c2-1', level: 'C2', words: ['Nicht', 'selten', 'wird', 'die', 'Komplexität', 'dieser', 'Fragestellung', 'unterschätzt.'], translation: 'Il n\'est pas rare que la complexité de cette problématique soit sous-estimée.', hint: 'Inversion stylistique : complément en tête.' },
  { id: 'sb-c2-2', level: 'C2', words: ['Je', 'mehr', 'man', 'sich', 'mit', 'dem', 'Thema', 'beschäftigt,', 'desto', 'deutlicher', 'werden', 'die', 'Widersprüche.'], translation: 'Plus on approfondit le sujet, plus les contradictions deviennent évidentes.', hint: 'Structure "je... desto...".' },
  { id: 'sb-c2-3', level: 'C2', words: ['Ungeachtet', 'aller', 'Bedenken', 'wurde', 'das', 'Gesetz', 'mit', 'knapper', 'Mehrheit', 'verabschiedet.'], translation: 'Malgré toutes les réserves, la loi a été adoptée à une faible majorité.', hint: 'Voix passive au prétérit.' },
];

// ── Context ───────────────────────────────────────────────────────────────

interface LearnContextType {
  progress: Progress;
  setProgress: React.Dispatch<React.SetStateAction<Progress>>;
  getLessonProgress: (lessonId: string) => { completed: boolean; score: number; attempts: number };
  markLessonComplete: (lessonId: string, score: number) => void;
  getLevelProgress: (level: LevelId) => { completed: number; total: number; percentage: number };
}

const LearnContext = createContext<LearnContextType | null>(null);

export function LearnProvider({ children }: { children: React.ReactNode }) {
  const [progress, setProgress] = useState<Progress>(() => {
    try {
      const saved = localStorage.getItem('dmr-progress');
      return saved ? JSON.parse(saved) : {};
    } catch { return {}; }
  });

  useEffect(() => {
    localStorage.setItem('dmr-progress', JSON.stringify(progress));
  }, [progress]);

  const getLessonProgress = useCallback((lessonId: string) => {
    return progress[lessonId] || { completed: false, score: 0, attempts: 0 };
  }, [progress]);

  const markLessonComplete = useCallback((lessonId: string, score: number) => {
    setProgress(prev => ({
      ...prev,
      [lessonId]: {
        completed: true,
        score: Math.max(score, prev[lessonId]?.score || 0),
        attempts: (prev[lessonId]?.attempts || 0) + 1,
      },
    }));
  }, []);

  const getLevelProgress = useCallback((level: LevelId) => {
    const levelLessons = LESSONS.filter(l => l.level === level);
    const completed = levelLessons.filter(l => progress[l.id]?.completed).length;
    return {
      completed,
      total: levelLessons.length,
      percentage: levelLessons.length > 0 ? Math.round((completed / levelLessons.length) * 100) : 0,
    };
  }, [progress]);

  return (
    <LearnContext.Provider value={{ progress, setProgress, getLessonProgress, markLessonComplete, getLevelProgress }}>
      {children}
    </LearnContext.Provider>
  );
}

export function useLearn() {
  const ctx = useContext(LearnContext);
  if (!ctx) throw new Error('useLearn must be used within LearnProvider');
  return ctx;
}

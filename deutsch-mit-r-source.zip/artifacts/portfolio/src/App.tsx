import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Toaster } from '@/components/ui/sonner';
import { TooltipProvider } from '@/components/ui/tooltip';
import { Route, Switch, Router as WouterRouter } from 'wouter';
import ErrorBoundary from '@/components/ErrorBoundary';
import { ThemeProvider } from '@/contexts/ThemeContext';
import { LearnProvider } from '@/contexts/LearnContext';
import Home from '@/pages/Home';
import Lecons from '@/pages/Lecons';
import Exercices from '@/pages/Exercices';
import IA from '@/pages/IA';
import Ecriture from '@/pages/Ecriture';
import Tests from '@/pages/Tests';
import NotFound from '@/pages/NotFound';

const queryClient = new QueryClient();

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/lecons" component={Lecons} />
      <Route path="/exercices" component={Exercices} />
      <Route path="/ia" component={IA} />
      <Route path="/ecriture" component={Ecriture} />
      <Route path="/tests" component={Tests} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark">
        <LearnProvider>
          <QueryClientProvider client={queryClient}>
            <TooltipProvider>
              <Toaster />
              <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
                <Router />
              </WouterRouter>
            </TooltipProvider>
          </QueryClientProvider>
        </LearnProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;

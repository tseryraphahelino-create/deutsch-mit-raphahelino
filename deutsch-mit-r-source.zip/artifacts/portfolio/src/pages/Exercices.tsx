import { useState, useMemo, useCallback } from 'react';
import { Brain, CheckCircle2, XCircle, ArrowRight, RotateCcw, Trophy, Zap, ChevronDown } from 'lucide-react';
import Layout from '@/components/Layout';
import { EXERCISES, LEVEL_COLORS, LESSONS, type LevelId } from '@/contexts/LearnContext';
import { useLearn } from '@/contexts/LearnContext';

const LEVELS: LevelId[] = ['A1', 'A2', 'B1', 'B2', 'C1', 'C2'];

export default function Exercices() {
  const [filterLevel, setFilterLevel] = useState<LevelId | 'all'>('all');
  const [currentIdx, setCurrentIdx] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [score, setScore] = useState(0);
  const [answered, setAnswered] = useState(0);
  const [finished, setFinished] = useState(false);
  const { markLessonComplete } = useLearn();

  const exercises = useMemo(() => {
    const base = filterLevel === 'all' ? EXERCISES : EXERCISES.filter(e => e.level === filterLevel);
    // Shuffle for variety
    return [...base].sort(() => 0);
  }, [filterLevel]);

  const current = exercises[currentIdx];
  const isCorrect = selected !== null && selected === current?.correctIndex;

  const handleSelect = useCallback((idx: number) => {
    if (selected !== null) return;
    setSelected(idx);
    setAnswered(prev => prev + 1);
    if (idx === current.correctIndex) {
      setScore(prev => prev + 1);
      // Mark the lesson as complete with partial score
      markLessonComplete(current.lessonId, Math.round(((score + 1) / (answered + 1)) * 100));
    }
  }, [selected, current, score, answered, markLessonComplete]);

  const handleNext = useCallback(() => {
    if (currentIdx >= exercises.length - 1) {
      setFinished(true);
    } else {
      setCurrentIdx(prev => prev + 1);
      setSelected(null);
    }
  }, [currentIdx, exercises.length]);

  const handleReset = useCallback(() => {
    setCurrentIdx(0);
    setSelected(null);
    setScore(0);
    setAnswered(0);
    setFinished(false);
  }, []);

  const handleLevelChange = useCallback((level: LevelId | 'all') => {
    setFilterLevel(level);
    setCurrentIdx(0);
    setSelected(null);
    setScore(0);
    setAnswered(0);
    setFinished(false);
  }, []);

  const pct = answered > 0 ? Math.round((score / answered) * 100) : 0;

  return (
    <Layout>
      <div className="container py-8 lg:py-12">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-2 mb-1">
            <Zap size={14} className="text-amber-400" />
            <span className="data-label">Quiz interactif</span>
          </div>
          <div className="flex items-center gap-3 mb-2">
            <Brain size={24} className="text-amber-400" />
            <h1 className="font-display text-2xl lg:text-3xl font-bold">Exercices</h1>
          </div>
          <p className="text-muted-foreground">
            {EXERCISES.length} questions QCM pour tester votre allemand, du A1 au C2.
          </p>
        </div>

        {/* Level filter */}
        <div className="flex flex-wrap gap-2 mb-8">
          <button
            onClick={() => handleLevelChange('all')}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${filterLevel === 'all' ? 'bg-primary text-primary-foreground' : 'bg-card border border-border text-muted-foreground hover:text-foreground'}`}
          >
            Tous ({EXERCISES.length})
          </button>
          {LEVELS.map(level => {
            const c = LEVEL_COLORS[level];
            const count = EXERCISES.filter(e => e.level === level).length;
            return (
              <button
                key={level}
                onClick={() => handleLevelChange(level)}
                className={`px-4 py-2 rounded-lg text-sm font-mono font-bold transition-all ${filterLevel === level ? `${c.bg} border ${c.border} ${c.text}` : 'bg-card border border-border text-muted-foreground hover:text-foreground'}`}
              >
                {level} ({count})
              </button>
            );
          })}
        </div>

        {exercises.length === 0 ? (
          <div className="text-center py-16">
            <Brain size={48} className="mx-auto text-muted-foreground/30 mb-4" />
            <p className="text-muted-foreground">Aucun exercice pour ce niveau.</p>
          </div>
        ) : finished ? (
          /* Results screen */
          <div className="max-w-lg mx-auto text-center space-y-6">
            <div className="bg-card border border-border rounded-2xl p-8 panel-hud circuit-corner">
              <Trophy size={48} className="mx-auto text-amber-400 mb-4" />
              <div className="text-5xl font-display font-bold text-primary mb-2">{pct}%</div>
              <p className="text-lg font-semibold text-foreground mb-1">{score}/{answered} bonnes réponses</p>
              <p className="text-sm text-muted-foreground">
                {pct >= 80 ? 'Excellent travail ! Sehr gut!' : pct >= 60 ? 'Bien ! Gut gemacht!' : 'Continue à pratiquer — Weiter üben!'}
              </p>
            </div>
            <div className="flex gap-3 justify-center">
              <button
                onClick={handleReset}
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg border border-border bg-card text-sm font-medium hover:bg-accent/10 transition-all"
              >
                <RotateCcw size={16} />
                Recommencer
              </button>
              <button
                onClick={() => { handleLevelChange('all'); }}
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-primary text-primary-foreground text-sm font-medium hover:opacity-90 transition-all"
              >
                Tous les niveaux
              </button>
            </div>
          </div>
        ) : (
          <div className="max-w-2xl mx-auto">
            {/* Progress bar */}
            <div className="panel-hud circuit-corner bg-card border border-border rounded-xl p-4 mb-6">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <span className="data-label">Question</span>
                  <span className="text-sm font-mono">{currentIdx + 1} / {exercises.length}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="data-label">Score</span>
                  <span className="text-sm font-mono text-primary">{score}/{answered}</span>
                </div>
              </div>
              <div className="h-1.5 bg-muted rounded-full overflow-hidden">
                <div
                  className="h-full bg-primary rounded-full transition-all duration-500"
                  style={{ width: `${((currentIdx + 1) / exercises.length) * 100}%` }}
                />
              </div>
            </div>

            {/* Question card */}
            {current && (() => {
              const colors = LEVEL_COLORS[current.level];
              const lessonTitle = LESSONS.find(l => l.id === current.lessonId)?.title;
              return (
                <div className={`bg-card border ${colors.border} rounded-2xl p-6 mb-4 panel-hud circuit-corner`}>
                  <div className="flex items-center gap-2 mb-4 flex-wrap">
                    <span className={`text-xs font-mono font-bold px-2.5 py-0.5 rounded-full border ${colors.bg} ${colors.text} ${colors.border}`}>
                      {current.level}
                    </span>
                    {lessonTitle && (
                      <span className="text-xs text-muted-foreground bg-muted px-2 py-0.5 rounded">
                        {lessonTitle}
                      </span>
                    )}
                  </div>

                  <p className="font-display text-base font-semibold text-foreground mb-6 leading-relaxed">
                    {current.question}
                  </p>

                  <div className="space-y-2.5">
                    {current.options.map((opt, i) => {
                      let style = 'bg-muted/30 border-border text-foreground hover:bg-accent/10';
                      if (selected !== null) {
                        if (i === current.correctIndex) {
                          style = 'bg-emerald-500/15 border-emerald-400 text-emerald-300';
                        } else if (i === selected && i !== current.correctIndex) {
                          style = 'bg-destructive/15 border-destructive text-destructive';
                        } else {
                          style = 'bg-muted/20 border-border/50 text-muted-foreground opacity-60';
                        }
                      }
                      return (
                        <button
                          key={i}
                          onClick={() => handleSelect(i)}
                          disabled={selected !== null}
                          className={`w-full text-left px-4 py-3 rounded-xl border text-sm font-mono transition-all duration-200 ${style} disabled:cursor-default`}
                        >
                          <span className="font-bold mr-3 text-muted-foreground">{String.fromCharCode(65 + i)}.</span>
                          {opt}
                        </button>
                      );
                    })}
                  </div>

                  {/* Explanation */}
                  {selected !== null && (
                    <div className={`mt-5 p-4 rounded-xl border ${isCorrect ? 'bg-emerald-500/10 border-emerald-400/30' : 'bg-amber-500/10 border-amber-400/30'}`}>
                      <p className="text-sm font-semibold flex items-center gap-2 mb-1">
                        {isCorrect
                          ? <><CheckCircle2 size={15} className="text-emerald-400" /> Richtig! Très bien !</>
                          : <><XCircle size={15} className="text-amber-400" /> Pas tout à fait...</>
                        }
                      </p>
                      <p className="text-xs text-muted-foreground leading-relaxed">💡 {current.explanation}</p>
                    </div>
                  )}
                </div>
              );
            })()}

            {/* Navigation */}
            <div className="flex items-center justify-between">
              <button
                onClick={handleReset}
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg border border-border bg-card text-sm font-medium hover:bg-accent/10 transition-all"
              >
                <RotateCcw size={15} />
                Réinitialiser
              </button>
              {selected !== null && (
                <button
                  onClick={handleNext}
                  className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-primary text-primary-foreground text-sm font-medium hover:opacity-90 transition-all active:scale-[0.97]"
                >
                  {currentIdx >= exercises.length - 1 ? 'Voir les résultats' : 'Suivant'}
                  <ArrowRight size={15} />
                </button>
              )}
            </div>
          </div>
        )}
      </div>
    </Layout>
  );
}

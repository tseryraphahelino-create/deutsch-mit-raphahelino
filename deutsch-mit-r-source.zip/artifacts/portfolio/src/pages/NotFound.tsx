import { Link } from 'wouter';
import { Home } from 'lucide-react';

export default function NotFound() {
  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-8">
      <div className="text-center space-y-6 max-w-md">
        <div className="text-8xl font-mono font-bold text-primary/30">404</div>
        <div>
          <h1 className="font-display text-2xl font-bold text-foreground mb-2">
            Seite nicht gefunden
          </h1>
          <p className="text-muted-foreground">
            Cette page n'existe pas. Retournez à l'accueil pour continuer votre apprentissage.
          </p>
        </div>
        <Link href="/">
          <div className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-primary text-primary-foreground text-sm font-medium hover:opacity-90 transition-all cursor-pointer">
            <Home size={16} />
            Retour à l'accueil
          </div>
        </Link>
      </div>
    </div>
  );
}

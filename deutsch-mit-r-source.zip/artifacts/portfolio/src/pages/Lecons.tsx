import { useState, useMemo } from 'react';
import { BookOpen, ChevronRight, CheckCircle2, X, Zap } from 'lucide-react';
import Layout from '@/components/Layout';
import { LESSONS, LEVEL_COLORS, LEVEL_NAMES, type LevelId, type Lesson } from '@/contexts/LearnContext';
import { useLearn } from '@/contexts/LearnContext';

const LEVELS: LevelId[] = ['A1', 'A2', 'B1', 'B2', 'C1', 'C2'];
const CATEGORIES = ['grammaire', 'vocabulaire', 'prononciation', 'culture'] as const;

const CATEGORY_LABELS: Record<string, string> = {
  grammaire: 'Grammaire',
  vocabulaire: 'Vocabulaire',
  prononciation: 'Prononciation',
  culture: 'Culture',
};

function LessonModal({ lesson, onClose }: { lesson: Lesson; onClose: () => void }) {
  const { getLessonProgress, markLessonComplete } = useLearn();
  const prog = getLessonProgress(lesson.id);
  const colors = LEVEL_COLORS[lesson.level];

  // Very simple markdown rendering (bold + newlines)
  const renderContent = (text: string) => {
    return text.split('\n').map((line, i) => {
      const parts = line.split(/\*\*(.*?)\*\*/g);
      return (
        <p key={i} className={`${line.startsWith('|') ? 'font-mono text-xs' : 'text-sm'} leading-relaxed ${line === '' ? 'mt-2' : ''}`}>
          {parts.map((part, j) =>
            j % 2 === 1 ? <strong key={j} className="text-foreground font-semibold">{part}</strong> : part
          )}
        </p>
      );
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center p-4 pt-8 bg-background/80 backdrop-blur-sm overflow-y-auto" onClick={onClose}>
      <div
        className="w-full max-w-2xl bg-card border border-border rounded-2xl shadow-2xl panel-hud circuit-corner my-4"
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className={`p-5 border-b border-border flex items-start justify-between gap-4`}>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-2 flex-wrap">
              <span className={`text-xs font-mono font-bold px-2 py-0.5 rounded-full border ${colors.bg} ${colors.text} ${colors.border}`}>
                {lesson.level}
              </span>
              <span className="text-xs text-muted-foreground bg-muted px-2 py-0.5 rounded-full">
                {CATEGORY_LABELS[lesson.category]}
              </span>
              {prog.completed && (
                <span className="flex items-center gap-1 text-xs text-emerald-400 bg-emerald-500/10 border border-emerald-400/20 px-2 py-0.5 rounded-full">
                  <CheckCircle2 size={12} />
                  Complété ({prog.score}pts)
                </span>
              )}
            </div>
            <h2 className="font-display text-xl font-bold text-foreground">{lesson.title}</h2>
            <p className="text-sm text-muted-foreground font-mono">{lesson.titleDe}</p>
          </div>
          <button onClick={onClose} className="p-2 rounded-lg hover:bg-accent/10 transition-colors shrink-0">
            <X size={18} />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 space-y-4 max-h-[60vh] overflow-y-auto">
          <div className="text-muted-foreground space-y-1">
            {renderContent(lesson.content)}
          </div>

          {lesson.examples.length > 0 && (
            <div className="mt-4 p-4 rounded-xl bg-primary/5 border border-primary/20">
              <p className="text-xs uppercase tracking-wider text-primary font-mono font-bold mb-3">Exemples</p>
              <div className="space-y-2">
                {lesson.examples.map((ex, i) => (
                  <p key={i} className="text-sm font-mono text-foreground/90 flex gap-2">
                    <span className="text-primary shrink-0">›</span>
                    {ex}
                  </p>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-border flex items-center justify-between gap-3">
          <p className="text-xs text-muted-foreground font-mono">
            {prog.attempts > 0 ? `Ouvert ${prog.attempts} fois` : 'Première lecture'}
          </p>
          {!prog.completed ? (
            <button
              onClick={() => { markLessonComplete(lesson.id, 100); onClose(); }}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-primary text-primary-foreground text-sm font-medium hover:opacity-90 transition-all"
            >
              <CheckCircle2 size={16} />
              Marquer comme lu
            </button>
          ) : (
            <span className="text-sm text-emerald-400 flex items-center gap-1.5 font-medium">
              <CheckCircle2 size={16} />
              Leçon complétée
            </span>
          )}
        </div>
      </div>
    </div>
  );
}

export default function Lecons() {
  const [filterLevel, setFilterLevel] = useState<LevelId | 'all'>('all');
  const [filterCat, setFilterCat] = useState<string>('all');
  const [selected, setSelected] = useState<Lesson | null>(null);
  const { getLessonProgress } = useLearn();

  const filtered = useMemo(() => {
    return LESSONS.filter(l => {
      if (filterLevel !== 'all' && l.level !== filterLevel) return false;
      if (filterCat !== 'all' && l.category !== filterCat) return false;
      return true;
    });
  }, [filterLevel, filterCat]);

  return (
    <Layout>
      <div className="container py-8 lg:py-12">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-2 mb-1">
            <Zap size={14} className="text-cyan-400" />
            <span className="data-label">Grammar & Vocabulary</span>
          </div>
          <div className="flex items-center gap-3 mb-2">
            <BookOpen size={24} className="text-cyan-400" />
            <h1 className="font-display text-2xl lg:text-3xl font-bold">Leçons</h1>
          </div>
          <p className="text-muted-foreground">
            {LESSONS.length} leçons de grammaire, vocabulaire et culture — de A1 à C2.
          </p>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap gap-2 mb-4">
          <button
            onClick={() => setFilterLevel('all')}
            className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${filterLevel === 'all' ? 'bg-primary text-primary-foreground' : 'bg-card border border-border text-muted-foreground hover:text-foreground'}`}
          >
            Tous
          </button>
          {LEVELS.map(level => {
            const c = LEVEL_COLORS[level];
            return (
              <button
                key={level}
                onClick={() => setFilterLevel(level)}
                className={`px-3 py-1.5 rounded-lg text-sm font-mono font-bold transition-all ${filterLevel === level ? `${c.bg} border ${c.border} ${c.text}` : 'bg-card border border-border text-muted-foreground hover:text-foreground'}`}
              >
                {level}
              </button>
            );
          })}
        </div>
        <div className="flex flex-wrap gap-2 mb-8">
          <button
            onClick={() => setFilterCat('all')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${filterCat === 'all' ? 'bg-secondary text-secondary-foreground' : 'bg-card border border-border text-muted-foreground hover:text-foreground'}`}
          >
            Toutes catégories
          </button>
          {CATEGORIES.map(cat => (
            <button
              key={cat}
              onClick={() => setFilterCat(cat)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${filterCat === cat ? 'bg-secondary text-secondary-foreground' : 'bg-card border border-border text-muted-foreground hover:text-foreground'}`}
            >
              {CATEGORY_LABELS[cat]}
            </button>
          ))}
        </div>

        {/* Count */}
        <p className="text-sm text-muted-foreground mb-4 font-mono">{filtered.length} leçon{filtered.length !== 1 ? 's' : ''}</p>

        {/* Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {filtered.map(lesson => {
            const prog = getLessonProgress(lesson.id);
            const colors = LEVEL_COLORS[lesson.level];
            return (
              <button
                key={lesson.id}
                onClick={() => setSelected(lesson)}
                className={`group text-left rounded-xl border ${colors.border} bg-card hover:bg-card/80 p-4 transition-all duration-200 hover:scale-[1.01] panel-hud circuit-corner relative overflow-hidden`}
              >
                {prog.completed && (
                  <div className="absolute top-3 right-3">
                    <CheckCircle2 size={14} className="text-emerald-400" />
                  </div>
                )}
                <div className="flex items-center gap-2 mb-3">
                  <span className={`text-xs font-mono font-bold px-2 py-0.5 rounded-full ${colors.bg} ${colors.text} border ${colors.border}`}>
                    {lesson.level}
                  </span>
                  <span className="text-[10px] text-muted-foreground bg-muted px-1.5 py-0.5 rounded">
                    {CATEGORY_LABELS[lesson.category]}
                  </span>
                </div>
                <h3 className="font-display font-semibold text-sm text-foreground mb-1 pr-6">{lesson.title}</h3>
                <p className="text-[11px] font-mono text-muted-foreground mb-2">{lesson.titleDe}</p>
                <p className="text-xs text-muted-foreground leading-relaxed line-clamp-2">{lesson.description}</p>
                <div className="flex items-center gap-1 mt-3 text-xs text-muted-foreground/60 group-hover:text-primary transition-colors">
                  <span>Ouvrir</span>
                  <ChevronRight size={12} className="group-hover:translate-x-0.5 transition-transform" />
                </div>
              </button>
            );
          })}
        </div>

        {filtered.length === 0 && (
          <div className="text-center py-16">
            <BookOpen size={48} className="mx-auto text-muted-foreground/30 mb-4" />
            <p className="text-muted-foreground">Aucune leçon pour ce filtre.</p>
          </div>
        )}
      </div>

      {selected && <LessonModal lesson={selected} onClose={() => setSelected(null)} />}
    </Layout>
  );
}

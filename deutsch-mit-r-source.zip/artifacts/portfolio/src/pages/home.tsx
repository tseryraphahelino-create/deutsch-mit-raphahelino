import React from 'react';
import { ArrowRight, ArrowUpRight, Mail, MapPin, Github, Linkedin, Twitter } from 'lucide-react';
import { FadeIn, StaggerContainer, StaggerItem } from '@/components/ui/fade-in';

export default function Home() {
  return (
    <div className="min-h-screen bg-background text-foreground overflow-hidden">
      
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 flex items-center justify-between px-6 py-6 mix-blend-difference text-white/90">
        <a href="#" className="text-sm font-medium tracking-widest uppercase hover:opacity-70 transition-opacity">
          E. Caldwell
        </a>
        <div className="hidden md:flex gap-8 text-sm font-medium">
          <a href="#about" className="hover:opacity-70 transition-opacity">About</a>
          <a href="#work" className="hover:opacity-70 transition-opacity">Work</a>
          <a href="#contact" className="hover:opacity-70 transition-opacity">Contact</a>
        </div>
        <a href="#contact" className="md:hidden text-sm font-medium hover:opacity-70 transition-opacity">
          Menu
        </a>
      </nav>

      {/* Hero Section */}
      <section className="relative min-h-[100dvh] flex flex-col justify-end pb-12 px-6 md:px-12 lg:px-24">
        {/* Abstract background elements */}
        <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none flex items-center justify-center opacity-30 mix-blend-multiply">
           <img 
             src="/hero.jpg" 
             alt="Architectural space" 
             className="w-full h-full object-cover grayscale opacity-20"
           />
        </div>

        <div className="relative z-10 w-full max-w-7xl mx-auto flex flex-col items-start pt-32">
          <FadeIn delay={0.2} direction="up">
            <h1 className="font-serif text-6xl md:text-8xl lg:text-[10rem] leading-[0.85] tracking-tight mb-8">
              Digital <br />
              <span className="italic font-light text-muted-foreground">Craft</span>
            </h1>
          </FadeIn>
          
          <div className="flex flex-col md:flex-row md:items-end justify-between w-full mt-12 md:mt-24">
            <FadeIn delay={0.4} className="max-w-md">
              <p className="text-lg md:text-xl text-muted-foreground leading-relaxed">
                I am Elena Caldwell. A senior design engineer specialized in 
                building interfaces that feel unhurried, intentional, and alive.
              </p>
            </FadeIn>
            
            <FadeIn delay={0.6} className="mt-8 md:mt-0 flex items-center gap-4">
              <span className="flex h-2 w-2 rounded-full bg-green-500 animate-pulse"></span>
              <span className="text-sm font-medium uppercase tracking-widest">Available for select projects</span>
            </FadeIn>
          </div>
        </div>
      </section>

      {/* About & Skills Section */}
      <section id="about" className="py-32 px-6 md:px-12 lg:px-24 bg-foreground text-background">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-16 lg:gap-8">
            <div className="lg:col-span-5">
              <FadeIn>
                <h2 className="font-serif text-5xl md:text-7xl mb-12">The<br/>Approach.</h2>
              </FadeIn>
              <FadeIn delay={0.2}>
                <div className="space-y-6 text-lg text-background/70 leading-relaxed font-light">
                  <p>
                    I believe the digital tools we use every day shouldn't feel like machines. 
                    They should feel like curated spaces—quiet, considered, and responsive.
                  </p>
                  <p>
                    Over the past decade, I've partnered with early-stage startups and established 
                    boutiques to bring a sense of physical craft to the browser. I bridge the gap 
                    between uncompromising aesthetic vision and robust technical execution.
                  </p>
                </div>
              </FadeIn>
            </div>
            
            <div className="lg:col-span-6 lg:col-start-7 pt-4 lg:pt-0">
              <StaggerContainer>
                <div className="border-t border-background/20 py-8">
                  <StaggerItem>
                    <div className="flex flex-col md:flex-row md:justify-between mb-4">
                      <h3 className="text-2xl font-serif">Engineering</h3>
                      <p className="text-background/50 text-sm mt-2 md:mt-0 uppercase tracking-widest">The Foundation</p>
                    </div>
                    <p className="text-background/70 leading-relaxed max-w-md">
                      React, TypeScript, Next.js, Framer Motion, WebGL. I write code that is as 
                      elegant under the hood as the interfaces it renders.
                    </p>
                  </StaggerItem>
                </div>
                
                <div className="border-t border-background/20 py-8">
                  <StaggerItem>
                    <div className="flex flex-col md:flex-row md:justify-between mb-4">
                      <h3 className="text-2xl font-serif">Design</h3>
                      <p className="text-background/50 text-sm mt-2 md:mt-0 uppercase tracking-widest">The Form</p>
                    </div>
                    <p className="text-background/70 leading-relaxed max-w-md">
                      Interaction design, typography, systems thinking, art direction. 
                      I don't just assemble components; I create visual languages.
                    </p>
                  </StaggerItem>
                </div>
                
                <div className="border-t border-background/20 py-8">
                  <StaggerItem>
                    <div className="flex flex-col md:flex-row md:justify-between mb-4">
                      <h3 className="text-2xl font-serif">Strategy</h3>
                      <p className="text-background/50 text-sm mt-2 md:mt-0 uppercase tracking-widest">The Purpose</p>
                    </div>
                    <p className="text-background/70 leading-relaxed max-w-md">
                      Product roadmapping, user flow optimization, brand positioning. 
                      Every pixel must serve the broader business objective.
                    </p>
                  </StaggerItem>
                </div>
              </StaggerContainer>
            </div>
          </div>
        </div>
      </section>

      {/* Selected Work Section */}
      <section id="work" className="py-32 px-6 md:px-12 lg:px-24">
        <div className="max-w-7xl mx-auto">
          <FadeIn>
            <div className="flex items-baseline gap-4 mb-20">
              <h2 className="font-serif text-5xl md:text-7xl">Selected Work</h2>
              <span className="text-muted-foreground text-xl">(21—24)</span>
            </div>
          </FadeIn>

          <div className="space-y-32">
            {/* Project 1 */}
            <div className="group relative">
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
                <div className="lg:col-span-7 order-2 lg:order-1 relative overflow-hidden bg-muted aspect-[4/3] w-full">
                  <FadeIn className="w-full h-full">
                    <img 
                      src="/project-1.jpg" 
                      alt="Aura Commerce" 
                      className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-105"
                    />
                  </FadeIn>
                </div>
                <div className="lg:col-span-4 lg:col-start-9 order-1 lg:order-2">
                  <FadeIn delay={0.2} direction="left">
                    <p className="text-sm font-medium uppercase tracking-widest text-muted-foreground mb-4">E-Commerce</p>
                    <h3 className="font-serif text-4xl mb-6">Aura Studios</h3>
                    <p className="text-muted-foreground mb-8 text-lg leading-relaxed">
                      A complete digital reinvention for a boutique fashion house. The interface 
                      mirrors their physical garments: structured, minimal, and entirely focused on texture.
                    </p>
                    <a href="#" className="inline-flex items-center gap-2 border-b border-foreground pb-1 hover:text-muted-foreground hover:border-muted-foreground transition-colors">
                      View Project <ArrowUpRight className="w-4 h-4" />
                    </a>
                  </FadeIn>
                </div>
              </div>
            </div>

            {/* Project 2 */}
            <div className="group relative">
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
                <div className="lg:col-span-4 order-1 lg:order-1 z-10">
                  <FadeIn delay={0.2} direction="right">
                    <p className="text-sm font-medium uppercase tracking-widest text-muted-foreground mb-4">Application</p>
                    <h3 className="font-serif text-4xl mb-6">Equilibrium</h3>
                    <p className="text-muted-foreground mb-8 text-lg leading-relaxed">
                      A wellness tracker that doesn't feel like a spreadsheet. We designed a 
                      calm, fluid interface that encourages reflection rather than gamification.
                    </p>
                    <a href="#" className="inline-flex items-center gap-2 border-b border-foreground pb-1 hover:text-muted-foreground hover:border-muted-foreground transition-colors">
                      View Project <ArrowUpRight className="w-4 h-4" />
                    </a>
                  </FadeIn>
                </div>
                <div className="lg:col-span-7 lg:col-start-6 order-2 lg:order-2 relative overflow-hidden bg-muted aspect-[4/3] w-full">
                  <FadeIn className="w-full h-full">
                    <img 
                      src="/project-2.jpg" 
                      alt="Equilibrium App" 
                      className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-105"
                    />
                  </FadeIn>
                </div>
              </div>
            </div>

            {/* Project 3 */}
            <div className="group relative">
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
                <div className="lg:col-span-7 order-2 lg:order-1 relative overflow-hidden bg-muted aspect-[4/3] w-full">
                  <FadeIn className="w-full h-full">
                    <img 
                      src="/project-3.jpg" 
                      alt="Kinetic Brand" 
                      className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-105"
                    />
                  </FadeIn>
                </div>
                <div className="lg:col-span-4 lg:col-start-9 order-1 lg:order-2">
                  <FadeIn delay={0.2} direction="left">
                    <p className="text-sm font-medium uppercase tracking-widest text-muted-foreground mb-4">Brand Identity</p>
                    <h3 className="font-serif text-4xl mb-6">The Kinetic Group</h3>
                    <p className="text-muted-foreground mb-8 text-lg leading-relaxed">
                      Physical and digital assets for an architecture firm. We translated their 
                      spatial principles into typography and grid systems that feel structural.
                    </p>
                    <a href="#" className="inline-flex items-center gap-2 border-b border-foreground pb-1 hover:text-muted-foreground hover:border-muted-foreground transition-colors">
                      View Project <ArrowUpRight className="w-4 h-4" />
                    </a>
                  </FadeIn>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-32 px-6 md:px-12 lg:px-24 bg-[#E8E6E1]">
        <div className="max-w-7xl mx-auto flex flex-col items-center text-center">
          <FadeIn>
            <p className="text-sm font-medium uppercase tracking-widest text-muted-foreground mb-8">Ready to start?</p>
            <h2 className="font-serif text-5xl md:text-8xl mb-12">Let's build<br/>something enduring.</h2>
            
            <a 
              href="mailto:hello@example.com" 
              className="inline-flex items-center justify-center gap-4 bg-foreground text-background px-8 py-5 rounded-full text-lg hover:bg-foreground/90 transition-transform hover:scale-105 active:scale-95 duration-200"
            >
              <Mail className="w-5 h-5" />
              hello@example.com
            </a>
          </FadeIn>

          <FadeIn delay={0.3} className="w-full mt-32 pt-8 border-t border-foreground/10 flex flex-col md:flex-row justify-between items-center gap-8">
            <div className="flex items-center gap-2 text-muted-foreground">
              <MapPin className="w-4 h-4" />
              <span>Brooklyn, New York</span>
            </div>
            
            <div className="flex items-center gap-6">
              <a href="#" className="text-muted-foreground hover:text-foreground transition-colors">
                <Github className="w-5 h-5" />
              </a>
              <a href="#" className="text-muted-foreground hover:text-foreground transition-colors">
                <Linkedin className="w-5 h-5" />
              </a>
              <a href="#" className="text-muted-foreground hover:text-foreground transition-colors">
                <Twitter className="w-5 h-5" />
              </a>
            </div>
            
            <div className="text-muted-foreground text-sm">
              &copy; {new Date().getFullYear()} Elena Caldwell. All rights reserved.
            </div>
          </FadeIn>
        </div>
      </section>
    </div>
  );
}

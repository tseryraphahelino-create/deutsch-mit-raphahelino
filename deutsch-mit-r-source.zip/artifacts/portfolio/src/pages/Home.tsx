import { Link } from 'wouter';
import { BookOpen, Brain, GraduationCap, PenLine, ArrowRight, Trophy, Zap, Star } from 'lucide-react';
import Layout from '@/components/Layout';
import { LESSONS, EXERCISES, AI_SCENARIOS, LEVEL_COLORS, LEVEL_NAMES, type LevelId } from '@/contexts/LearnContext';
import { useLearn } from '@/contexts/LearnContext';

const LEVELS: LevelId[] = ['A1', 'A2', 'B1', 'B2', 'C1', 'C2'];

const features = [
  { icon: BookOpen, label: 'Leçons', desc: `${LESSONS.length} leçons A1–C2`, href: '/lecons', color: 'text-cyan-400', bg: 'bg-cyan-500/10', border: 'border-cyan-400/20' },
  { icon: Brain, label: 'Exercices', desc: `${EXERCISES.length} exercices QCM`, href: '/exercices', color: 'text-amber-400', bg: 'bg-amber-500/10', border: 'border-amber-400/20' },
  { icon: GraduationCap, label: 'Pratique IA', desc: `${AI_SCENARIOS.length} scénarios`, href: '/ia', color: 'text-violet-400', bg: 'bg-violet-500/10', border: 'border-violet-400/20' },
  { icon: PenLine, label: 'Écriture', desc: 'Construction & correction', href: '/ecriture', color: 'text-emerald-400', bg: 'bg-emerald-500/10', border: 'border-emerald-400/20' },
];

export default function Home() {
  const { getLevelProgress, progress } = useLearn();
  const completedTotal = Object.values(progress).filter(p => p.completed).length;
  const totalLessons = LESSONS.length;
  const globalPct = totalLessons > 0 ? Math.round((completedTotal / totalLessons) * 100) : 0;

  // Find next recommended level to study
  const nextLevel = LEVELS.find(l => {
    const prog = getLevelProgress(l);
    return prog.percentage < 100;
  }) ?? 'A1';

  return (
    <Layout>
      <div className="container py-8 lg:py-12 max-w-5xl">

        {/* Hero */}
        <div className="mb-12 relative">
          <div className="absolute -top-4 -left-4 w-32 h-32 bg-primary/5 rounded-full blur-2xl pointer-events-none" />
          <div className="relative">
            <div className="flex items-center gap-2 mb-3">
              <Zap size={14} className="text-primary" />
              <span className="data-label">Plateforme d'apprentissage</span>
            </div>
            <h1 className="font-display text-3xl lg:text-5xl font-bold text-foreground mb-3 leading-tight">
              Deutsch mit R.
              <span className="block text-primary text-2xl lg:text-3xl mt-1">de A1 à C2</span>
            </h1>
            <p className="text-muted-foreground max-w-xl leading-relaxed">
              Apprenez l'allemand avec une méthode structurée et progressive.
              Leçons, exercices interactifs et scénarios de conversation — tout en un.
            </p>

            {/* Global progress */}
            {completedTotal > 0 && (
              <div className="mt-6 inline-flex items-center gap-3 bg-card border border-border rounded-xl px-4 py-3 panel-hud circuit-corner">
                <Trophy size={18} className="text-amber-400 shrink-0" />
                <div>
                  <p className="text-xs text-muted-foreground font-mono">Progression globale</p>
                  <p className="text-sm font-bold text-foreground">{completedTotal}/{totalLessons} leçons — {globalPct}%</p>
                </div>
                <div className="w-20 h-1.5 bg-muted rounded-full overflow-hidden ml-2">
                  <div className="h-full bg-amber-400 rounded-full transition-all duration-700" style={{ width: `${globalPct}%` }} />
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Quick access */}
        <section className="mb-12">
          <h2 className="font-display text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
            <Star size={16} className="text-primary" />
            Modules
          </h2>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
            {features.map(f => (
              <Link key={f.href} href={f.href}>
                <div className={`group rounded-xl border ${f.border} ${f.bg} p-4 hover:scale-[1.02] transition-all duration-200 cursor-pointer panel-hud circuit-corner`}>
                  <f.icon size={22} className={`${f.color} mb-3`} />
                  <p className="font-display font-semibold text-sm text-foreground">{f.label}</p>
                  <p className="text-xs text-muted-foreground mt-0.5">{f.desc}</p>
                  <ArrowRight size={14} className={`${f.color} mt-3 group-hover:translate-x-1 transition-transform`} />
                </div>
              </Link>
            ))}
          </div>
        </section>

        {/* CEFR levels */}
        <section className="mb-12">
          <h2 className="font-display text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
            <BookOpen size={16} className="text-primary" />
            Niveaux CEFR
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {LEVELS.map(level => {
              const prog = getLevelProgress(level);
              const info = LEVEL_NAMES[level];
              const colors = LEVEL_COLORS[level];
              const lessonCount = LESSONS.filter(l => l.level === level).length;
              const isRecommended = level === nextLevel && completedTotal < totalLessons;

              return (
                <Link key={level} href={`/lecons?level=${level}`}>
                  <div className={`relative group rounded-xl border ${colors.border} ${colors.bg} p-5 hover:scale-[1.01] transition-all duration-200 cursor-pointer overflow-hidden`}>
                    {isRecommended && (
                      <div className="absolute top-2 right-2">
                        <span className="text-[9px] font-mono font-bold uppercase bg-primary text-primary-foreground px-1.5 py-0.5 rounded-full">
                          Suivant
                        </span>
                      </div>
                    )}
                    <div className="flex items-center gap-3 mb-3">
                      <span className={`font-mono text-xl font-bold ${colors.text}`}>{level}</span>
                      <div>
                        <p className="font-display font-semibold text-sm text-foreground">{info.fr}</p>
                        <p className="text-[10px] font-mono text-muted-foreground">{info.de}</p>
                      </div>
                    </div>
                    <p className="text-xs text-muted-foreground mb-4 leading-relaxed">{info.desc}</p>
                    <div className="space-y-1.5">
                      <div className="flex justify-between text-[10px] font-mono">
                        <span className="text-muted-foreground">{prog.completed}/{prog.total} leçons</span>
                        <span className={colors.text}>{prog.percentage}%</span>
                      </div>
                      <div className="h-1.5 bg-muted/50 rounded-full overflow-hidden">
                        <div
                          className={`h-full rounded-full transition-all duration-700 ${
                            level === 'A1' ? 'bg-emerald-400' :
                            level === 'A2' ? 'bg-blue-400' :
                            level === 'B1' ? 'bg-cyan-400' :
                            level === 'B2' ? 'bg-amber-400' :
                            level === 'C1' ? 'bg-violet-400' : 'bg-rose-400'
                          }`}
                          style={{ width: `${prog.percentage}%` }}
                        />
                      </div>
                    </div>
                    <p className="text-[10px] text-muted-foreground/60 mt-3 font-mono">{lessonCount} leçons disponibles</p>
                  </div>
                </Link>
              );
            })}
          </div>
        </section>

        {/* Start CTA */}
        <div className="bg-card border border-border rounded-2xl p-6 panel-hud circuit-corner flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <h3 className="font-display text-lg font-bold text-foreground mb-1">Prêt à commencer ?</h3>
            <p className="text-sm text-muted-foreground">Commencez par les bases ou reprenez là où vous en étiez.</p>
          </div>
          <div className="flex gap-3 shrink-0">
            <Link href="/exercices">
              <div className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg border border-border bg-card text-sm font-medium text-foreground hover:bg-accent/10 transition-all cursor-pointer">
                <Brain size={16} />
                Exercices
              </div>
            </Link>
            <Link href="/lecons">
              <div className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-primary text-primary-foreground text-sm font-medium hover:opacity-90 transition-all cursor-pointer">
                <BookOpen size={16} />
                Leçons
                <ArrowRight size={16} />
              </div>
            </Link>
          </div>
        </div>

      </div>
    </Layout>
  );
}

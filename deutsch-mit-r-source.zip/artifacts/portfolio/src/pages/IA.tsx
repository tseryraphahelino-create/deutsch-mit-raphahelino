import { useState } from 'react';
import {
  GraduationCap, Zap, ArrowLeft, BookOpen, Lightbulb,
  Volume2, MessageSquare, CheckCircle2, XCircle, ChevronRight,
  Trophy, RotateCcw, Star
} from 'lucide-react';
import Layout from '@/components/Layout';
import { AI_SCENARIOS, LEVEL_COLORS, type LevelId, type AIScenario } from '@/contexts/LearnContext';

// ── Dialogue Data ──────────────────────────────────────────────────────────

interface DialogueOption {
  text: string;
  isCorrect: boolean;
  feedback: string;
}

interface DialogueTurn {
  tutorMessage: string;
  tutorNote?: string; // grammar tip shown above options
  options: DialogueOption[];
}

const DIALOGUES: Record<string, DialogueTurn[]> = {
  'a1-cafe': [
    {
      tutorMessage: 'Hallo! Willkommen im Café Berlin. Was möchten Sie bestellen?',
      tutorNote: 'Utilisez "Ich hätte gern..." ou "Ich möchte..." pour commander.',
      options: [
        { text: 'Ich hätte gern einen Kaffee, bitte.', isCorrect: true, feedback: '✓ Parfait ! "Ich hätte gern..." est la formule polie pour commander. L\'article "einen" est à l\'accusatif.' },
        { text: 'Ich will Kaffee.', isCorrect: false, feedback: '✗ "Ich will" est brusque. Préférez "Ich möchte" ou "Ich hätte gern" pour être poli.' },
        { text: 'Kaffee geben!', isCorrect: false, feedback: '✗ Cette phrase est incorrecte et impolie. En allemand, la structure sujet + verbe est obligatoire.' },
      ],
    },
    {
      tutorMessage: 'Sehr gerne! Möchten Sie auch etwas essen? Wir haben frischen Kuchen.',
      tutorNote: '"Auch" = aussi. "Frisch" = frais. L\'adjectif s\'accorde avec le nom.',
      options: [
        { text: 'Ja, ich nehme ein Stück Kuchen, danke!', isCorrect: true, feedback: '✓ Excellent ! "Ein Stück" = un morceau. "Ich nehme" = je prends. Très naturel !' },
        { text: 'Nein, kein Hunger habe ich.', isCorrect: false, feedback: '✗ La structure est incorrecte. Le verbe doit être en 2e position : "Nein, ich habe keinen Hunger."' },
        { text: 'Was kostet das Kuchen?', isCorrect: false, feedback: '✗ "Kuchen" est masculin : "Was kostet der Kuchen?" — mais vous devriez d\'abord répondre à la question.' },
      ],
    },
    {
      tutorMessage: 'Ein Kaffee und ein Stück Schwarzwälder Kirschtorte — sehr gut! Das macht 6,50 Euro zusammen.',
      tutorNote: '"Das macht..." = ça fait... (pour le prix). "Zusammen" = en tout.',
      options: [
        { text: 'Hier, bitte. Und die Rechnung, bitte!', isCorrect: true, feedback: '✓ Bravo ! "Die Rechnung" = l\'addition. Formuler les deux en une phrase est très courant et naturel.' },
        { text: 'Ich zahle jetzt.', isCorrect: true, feedback: '✓ Correct ! "Ich zahle" = je paie. Simple et efficace. Vous pourriez ajouter "bitte" pour plus de politesse.' },
        { text: 'Sehr teuer! Ich habe kein Geld.', isCorrect: false, feedback: '✗ Grammaticalement correct mais inapproprié ici. "Teuer" = cher. "Ich habe kein Geld" = je n\'ai pas d\'argent.' },
      ],
    },
    {
      tutorMessage: 'Danke schön! Hat es Ihnen geschmeckt? Kommen Sie wieder!',
      tutorNote: '"Hat es geschmeckt?" = C\'était bon ? (litt. ça vous a goûté?) — expression très courante.',
      options: [
        { text: 'Ja, es war sehr lecker! Auf Wiedersehen!', isCorrect: true, feedback: '✓ Parfait ! "Lecker" = délicieux. "Auf Wiedersehen" = au revoir (formel). Score maximum !' },
        { text: 'Danke, tschüss!', isCorrect: true, feedback: '✓ Bien ! Court mais poli. "Tschüss" est légèrement plus familier qu\'"Auf Wiedersehen".' },
        { text: 'Ja gut. Bye bye.', isCorrect: false, feedback: '✗ Mélanger "ja gut" (allemand) et "bye bye" (anglais) est à éviter. Restez en allemand : "Danke, auf Wiedersehen!"' },
      ],
    },
  ],

  'a1-familie': [
    {
      tutorMessage: 'Hallo! Ich heiße Klaus. Und du? Hast du Geschwister?',
      tutorNote: '"Geschwister" = frères et sœurs (pluriel). "Hast du...?" = As-tu...?',
      options: [
        { text: 'Hallo Klaus! Ich heiße Marie. Ja, ich habe einen Bruder.', isCorrect: true, feedback: '✓ Parfait ! "Einen Bruder" = un frère (accusatif masculin). Présentation complète et naturelle.' },
        { text: 'Ja, ich habe Geschwister zwei.', isCorrect: false, feedback: '✗ L\'ordre est incorrect. En allemand : "Ich habe zwei Geschwister." (le chiffre avant le nom).' },
        { text: 'Mein Name ist Marie. Ich bin eine Schwester.', isCorrect: false, feedback: '✗ "Ich bin eine Schwester" signifie "je suis une sœur" (la sœur de quelqu\'un). Dites plutôt "Ich habe eine Schwester".' },
      ],
    },
    {
      tutorMessage: 'Oh, toll! Ich habe auch einen Bruder. Wie alt ist er? Und deine Eltern, wo wohnen sie?',
      tutorNote: '"Toll" = super/chouette. "Eltern" = parents. "Wo wohnen sie?" = Où habitent-ils ?',
      options: [
        { text: 'Er ist 22 Jahre alt. Meine Eltern wohnen in Lyon, in Frankreich.', isCorrect: true, feedback: '✓ Excellent ! "Jahre alt" pour l\'âge, "wohnen in" pour la ville. Structure parfaite.' },
        { text: 'Er hat 22 Jahre. Meine Eltern sind in Lyon.', isCorrect: false, feedback: '✗ En allemand, on dit "Er ist 22 Jahre alt" (pas "hat"). "Sind in Lyon" est acceptable mais "wohnen in Lyon" est plus précis.' },
        { text: 'Meine Eltern wohnen Frankreich.', isCorrect: false, feedback: '✗ Il manque la préposition : "Meine Eltern wohnen in Frankreich." La préposition "in" est obligatoire.' },
      ],
    },
    {
      tutorMessage: 'Interessant! Was macht dein Vater beruflich? Ist er auch in Frankreich?',
      tutorNote: '"Was machst du beruflich?" = Que fais-tu comme métier ? "Beruflich" = professionnellement.',
      options: [
        { text: 'Ja, er wohnt in Lyon. Er ist Ingenieur von Beruf.', isCorrect: true, feedback: '✓ Très bien ! "Von Beruf" est l\'expression standard pour parler du métier. "Er ist Ingenieur" est correct (sans article avec les métiers).' },
        { text: 'Mein Vater ist ein Arzt.', isCorrect: false, feedback: '✗ En allemand, avec les métiers après "sein", on n\'utilise PAS d\'article : "Mein Vater ist Arzt." (sans "ein").' },
        { text: 'Er macht Lehrer.', isCorrect: false, feedback: '✗ "Machen" ne s\'utilise pas avec les métiers. Dites : "Er ist Lehrer." (Il est professeur).' },
      ],
    },
    {
      tutorMessage: 'Cool! Und du, was machst du? Studierst du oder arbeitest du?',
      tutorNote: '"Studieren" = étudier à l\'université. "Arbeiten" = travailler. Verbes réguliers en -en.',
      options: [
        { text: 'Ich studiere Germanistik an der Universität in Paris.', isCorrect: true, feedback: '✓ Bravo ! "Germanistik" = études allemandes. "An der Universität" = à l\'université (datif). Réponse exemplaire !' },
        { text: 'Ich lerne Deutsch in der Schule.', isCorrect: true, feedback: '✓ Bien dit ! "Ich lerne Deutsch" = j\'apprends l\'allemand. Simple et correct.' },
        { text: 'Ich studiere seit zwei Jahren Deutsch lernen.', isCorrect: false, feedback: '✗ On ne peut pas combiner "studieren" et "lernen" ainsi. Choisissez l\'un ou l\'autre : "Ich lerne seit zwei Jahren Deutsch." ou "Ich studiere Germanistik."' },
      ],
    },
  ],

  'a2-bahnhof': [
    {
      tutorMessage: 'Guten Tag! Kann ich Ihnen helfen?',
      tutorNote: 'Formulez votre demande avec "Ich möchte..." ou "Ich hätte gern...".',
      options: [
        { text: 'Ja, bitte. Ich möchte eine Fahrkarte nach München kaufen.', isCorrect: true, feedback: '✓ Parfait ! "Fahrkarte" = billet. "Nach" + ville (accusatif pour les villes).' },
        { text: 'Ich will ein Ticket haben für München.', isCorrect: false, feedback: '✗ La structure est maladroite. Préférez : "Ich möchte ein Ticket nach München." "Für" est incorrect ici, utilisez "nach".' },
        { text: 'München fahren bitte!', isCorrect: false, feedback: '✗ Cette phrase n\'est pas grammaticalement correcte. Il manque le sujet et le verbe conjugué : "Ich möchte nach München fahren."' },
      ],
    },
    {
      tutorMessage: 'Gerne! Wann möchten Sie fahren — und einfache Fahrt oder Hin- und Rückfahrt?',
      tutorNote: '"Einfache Fahrt" = aller simple. "Hin- und Rückfahrt" = aller-retour.',
      options: [
        { text: 'Ich fahre morgen, am 10. Juli. Bitte eine einfache Fahrt.', isCorrect: true, feedback: '✓ Excellent ! "Am 10. Juli" = le 10 juillet (datif + génitif). Formulation parfaite et claire.' },
        { text: 'Morgen bitte, und Hin- und Rückfahrt.', isCorrect: true, feedback: '✓ Correct et naturel ! Court et efficace. En situation réelle, c\'est tout à fait approprié.' },
        { text: 'Ich gehe morgen und komme zurück.', isCorrect: false, feedback: '✗ "Gehen" signifie "marcher/aller à pied". Pour les transports, utilisez "fahren". De plus, vous n\'avez pas répondu sur le type de billet.' },
      ],
    },
    {
      tutorMessage: 'Der nächste Zug fährt um 14:37 Uhr ab. Das dauert 1 Stunde 20 Minuten. Von Gleis 7. Kostet 47,90 €.',
      tutorNote: '"Abfahren" (séparable) = partir. "Dauern" = durer. "Das Gleis" = le quai (de voie ferrée).',
      options: [
        { text: 'Von welchem Bahnsteig fährt der Zug ab? Und muss ich umsteigen?', isCorrect: true, feedback: '✓ Bravo ! Bonnes questions ! "Umsteigen" = changer de train. "Von welchem Bahnsteig" = de quel quai. Très pertinent !' },
        { text: 'Okay, ich nehme das. Hier ist meine Karte.', isCorrect: true, feedback: '✓ Bien ! Direct et efficace. "Ich nehme das" = je le prends. Naturel en situation réelle.' },
        { text: 'Ist das billig oder teuer?', isCorrect: false, feedback: '✗ La question est hors de propos — le prix vient d\'être donné (47,90 €). Demandez plutôt si vous devez changer ("Muss ich umsteigen?").' },
      ],
    },
    {
      tutorMessage: 'Kein Umstieg notwendig — Direktverbindung! Möchten Sie auch einen Sitzplatz reservieren?',
      tutorNote: '"Notwendig" = nécessaire. "Direktverbindung" = train direct. "Reservieren" = réserver.',
      options: [
        { text: 'Ja, bitte am Fenster, wenn möglich.', isCorrect: true, feedback: '✓ Parfait ! "Am Fenster" = côté fenêtre. "Wenn möglich" = si possible. Expression très courante et utile !' },
        { text: 'Nein danke, das ist nicht nötig.', isCorrect: true, feedback: '✓ Correct ! "Nicht nötig" = inutile. "Nicht notwendig" fonctionnerait aussi. Réponse claire.' },
        { text: 'Ja, ich will vorne sitzen.', isCorrect: false, feedback: '✗ "Vorne" = à l\'avant, mais dans un train on dit "am Fenster" (fenêtre) ou "am Gang" (couloir). "Ich will" est un peu brusque.' },
      ],
    },
  ],

  'a2-arzt': [
    {
      tutorMessage: 'Guten Tag! Was fehlt Ihnen? Wo tut es weh?',
      tutorNote: '"Was fehlt Ihnen?" = Qu\'est-ce qui ne va pas ? "Tut es weh" = ça fait mal.',
      options: [
        { text: 'Ich fühle mich nicht gut. Mein Hals tut sehr weh und ich habe Fieber.', isCorrect: true, feedback: '✓ Excellent ! "Sich fühlen" = se sentir. "Der Hals" = la gorge. "Fieber haben" = avoir de la fièvre. Description médicale parfaite !' },
        { text: 'Ich bin krank. Kopfschmerzen.', isCorrect: false, feedback: '✗ "Kopfschmerzen" = maux de tête — le mot est correct ! Mais formulez une phrase complète : "Ich habe starke Kopfschmerzen."' },
        { text: 'Ich habe Problem mit mein Bauch.', isCorrect: false, feedback: '✗ Erreurs : "ein Problem" (article), "meinem Bauch" (datif après "mit"). Correctement : "Ich habe ein Problem mit meinem Bauch."' },
      ],
    },
    {
      tutorMessage: 'Seit wann haben Sie diese Beschwerden? Haben Sie gehustet oder geschnupft?',
      tutorNote: '"Beschwerden" = symptômes/plaintes. "Husten" = tousser. "Schnupfen" = rhume/nez qui coule.',
      options: [
        { text: 'Seit gestern Abend. Ja, ich huste viel und habe Schnupfen.', isCorrect: true, feedback: '✓ Très bien ! "Seit" + datif pour la durée. "Schnupfen haben" = avoir le rhume. Réponse médicalement précise.' },
        { text: 'Vor drei Tagen hat es angefangen.', isCorrect: true, feedback: '✓ Correct ! "Vor drei Tagen" = il y a trois jours. Notez la différence : "seit" (depuis, continu) vs "vor" (il y a, point dans le temps).' },
        { text: 'Ich habe gestern gegessen und dann war schlecht.', isCorrect: false, feedback: '✗ "Es war mir schlecht" (j\'avais mal au cœur) est l\'expression correcte. Il manque aussi "mir" : "Dann war mir schlecht."' },
      ],
    },
    {
      tutorMessage: 'Ich verstehe. Haben Sie Allergien oder nehmen Sie regelmäßig Medikamente?',
      tutorNote: '"Allergien" = allergies. "Regelmäßig" = régulièrement. "Medikamente nehmen" = prendre des médicaments.',
      options: [
        { text: 'Nein, keine Allergien. Ich nehme keine regelmäßigen Medikamente.', isCorrect: true, feedback: '✓ Parfait ! "Keine Allergien" (accusatif pluriel). "Regelmäßigen Medikamente" — bon accord de l\'adjectif après "keine".' },
        { text: 'Ich bin allergisch gegen Penicillin.', isCorrect: true, feedback: '✓ Excellent ! "Allergisch gegen" = allergique à. Information médicale cruciale, très bien formulée !' },
        { text: 'Ich habe keine Allergien und Medikamente nicht.', isCorrect: false, feedback: '✗ La deuxième partie est incorrecte. Dites : "Ich nehme keine Medikamente." (Le verbe ne peut pas être omis en allemand standard).' },
      ],
    },
    {
      tutorMessage: 'Ich schreibe Ihnen ein Rezept. Ruhen Sie sich aus und trinken Sie viel! Kommen Sie in drei Tagen wieder, wenn es nicht besser wird.',
      tutorNote: '"Ruhen Sie sich aus!" = Reposez-vous ! (impératif formel). "Ausruhen" est un verbe séparable.',
      options: [
        { text: 'Vielen Dank, Herr Doktor. Bis wann soll ich die Tabletten nehmen?', isCorrect: true, feedback: '✓ Bravo ! Question très pertinente. "Bis wann" = jusqu\'à quand. "Tabletten" = comprimés. Parfait !' },
        { text: 'Danke schön. Auf Wiedersehen!', isCorrect: true, feedback: '✓ Correct et poli. En situation réelle, c\'est une clôture appropriée. "Auf Wiedersehen" convient au contexte médical formel.' },
        { text: 'Okay. Ich gehe jetzt schlafen.', isCorrect: false, feedback: '✗ Réponse grammaticalement correcte mais manque de politesse pour la fin d\'une consultation. Ajoutez au moins "Danke" et "Auf Wiedersehen".' },
      ],
    },
  ],

  'b1-meinung': [
    {
      tutorMessage: 'Ich denke, dass öffentliche Verkehrsmittel sehr wichtig sind. Was meinen Sie?',
      tutorNote: 'Exprimez votre opinion : "Meiner Meinung nach...", "Ich finde, dass...", "Ich bin der Ansicht, dass..."',
      options: [
        { text: 'Meiner Meinung nach sind öffentliche Verkehrsmittel unverzichtbar, besonders für die Umwelt.', isCorrect: true, feedback: '✓ Excellent ! "Meiner Meinung nach" + verbe en 2e position. "Unverzichtbar" = indispensable. Niveau B1/B2 !' },
        { text: 'Ich auch. Züge und Busse sind sehr gut.', isCorrect: false, feedback: '✗ "Ich auch" seul est trop court. Pour une discussion, développez : "Ich stimme zu. Züge und Busse sind sehr wichtig, weil..." suivi d\'un argument.' },
        { text: 'Ja, Verkehrsmittel ist wichtig.', isCorrect: false, feedback: '✗ "Verkehrsmittel" est pluriel : "Verkehrsmittel SIND wichtig". De plus, pour une discussion, ajoutez un argument : "weil sie die Umwelt schonen."' },
      ],
    },
    {
      tutorMessage: 'Das stimmt. Aber sind öffentliche Verkehrsmittel wirklich für alle zugänglich? Was ist mit den Kosten?',
      tutorNote: '"Zugänglich" = accessible. Utilisez "einerseits... andererseits..." pour structurer votre argument.',
      options: [
        { text: 'Einerseits sind sie günstiger als ein Auto, andererseits können sie in ländlichen Gebieten schlecht erreichbar sein.', isCorrect: true, feedback: '✓ Bravo ! Structure "einerseits... andererseits" parfaite. "Ländlich" = rural. "Erreichbar" = accessible. Argumentation équilibrée !' },
        { text: 'Die Kosten sind manchmal hoch, das ist ein Problem für ärmere Menschen.', isCorrect: true, feedback: '✓ Bon argument ! "Manchmal" = parfois. "Ärmere Menschen" = les personnes moins aisées. Réponse pertinente et nuancée.' },
        { text: 'Ja, das ist ein gutes Problem.', isCorrect: false, feedback: '✗ "Ein gutes Problem" est une contradiction. Dites : "das ist ein wichtiges Thema" ou "das ist tatsächlich ein Problem". Attention aux collocations.' },
      ],
    },
    {
      tutorMessage: 'Interessant! Glauben Sie, dass die Politik mehr investieren sollte? Und wie könnten Städte attraktiver gemacht werden?',
      tutorNote: 'Utilisez "sollte" (Konjunktiv II) pour les suggestions. "Ich finde, dass..." + verbe en fin.',
      options: [
        { text: 'Ja, ich finde, dass die Regierung mehr in den Nahverkehr investieren sollte, zum Beispiel durch günstigere Tickets.', isCorrect: true, feedback: '✓ Parfait ! "Nahverkehr" = transports locaux. "Zum Beispiel" = par exemple. Konjunktiv II "sollte" bien utilisé. Excellent B1 !' },
        { text: 'Die Städte könnten mehr Fahrradwege bauen und Parkplätze reduzieren.', isCorrect: true, feedback: '✓ Excellent ! "Könnten" = Konjunktiv II de können. "Fahrradwege" = pistes cyclables. Suggestion concrète et bien formulée !' },
        { text: 'Ja die Politik muss mehr Geld geben.', isCorrect: false, feedback: '✗ Correct mais trop simple. Pour un B1, développez : "Ich glaube, dass die Politik mehr investieren muss, weil..." et ajoutez un argument.' },
      ],
    },
    {
      tutorMessage: 'Sehr überzeugend! Zum Schluss: Was ist für Sie persönlich das stärkste Argument für öffentliche Verkehrsmittel?',
      tutorNote: '"Überzeugend" = convaincant. "Zum Schluss" = pour conclure. Résumez en une phrase forte.',
      options: [
        { text: 'Das stärkste Argument ist für mich der Umweltschutz — weniger Autos bedeuten weniger CO₂-Emissionen.', isCorrect: true, feedback: '✓ Conclusion remarquable ! "Umweltschutz" = protection de l\'environnement. Structure logique cause-effet. Niveau B1+ atteint !' },
        { text: 'Für mich persönlich ist der soziale Aspekt am wichtigsten: alle können mobil sein, unabhängig vom Einkommen.', isCorrect: true, feedback: '✓ Bravo ! "Unabhängig vom Einkommen" = indépendamment du revenu. Argument social fort, très bien articulé !' },
        { text: 'Busse und Züge sind gut. Das ist mein Argument.', isCorrect: false, feedback: '✗ Trop vague pour conclure une discussion B1. Formulez un argument avec "weil" : "...weil sie die Umwelt schonen und für alle zugänglich sind."' },
      ],
    },
  ],

  'b1-reise': [
    {
      tutorMessage: 'Hey! Ich habe Zeit im August. Wohin möchtest du reisen?',
      tutorNote: 'Faites des suggestions avec "Wir könnten..." (Konjunktiv II). Exprimez vos préférences.',
      options: [
        { text: 'Ich würde gerne nach Bayern fahren — die Berge und Seen dort sollen wunderschön sein.', isCorrect: true, feedback: '✓ Excellent ! "Würde gerne" = Konjunktiv II pour la préférence. "Sollen" rapporte ce qu\'on dit d\'une chose. Très naturel !' },
        { text: 'Wir könnten Hamburg besuchen. Ich war noch nie dort und ich liebe Hafenstädte.', isCorrect: true, feedback: '✓ Parfait ! "Noch nie" = jamais encore. "Könnten" = Konjunktiv II de können. Structure fluide et expressive.' },
        { text: 'Ich will gehen nach Berlin.', isCorrect: false, feedback: '✗ Erreur de structure : "Ich will nach Berlin fahren/gehen." Le verbe de direction vient à la fin. Aussi, "fahren" est plus courant que "gehen" pour les voyages.' },
      ],
    },
    {
      tutorMessage: 'Oh, Bayern klingt super! Wie lange würdest du gerne bleiben? Und was für Unterkunft suchst du?',
      tutorNote: '"Klingen" = sonner/sembler. "Wie lange" = combien de temps. "Unterkunft" = hébergement.',
      options: [
        { text: 'Ich würde gerne etwa eine Woche bleiben. Am liebsten in einem Hostel oder einer kleinen Pension.', isCorrect: true, feedback: '✓ Parfait ! "Etwa" = environ. "Am liebsten" = de préférence (superlatif d\'amour). "Pension" = pension de famille. Très naturel !' },
        { text: 'Ungefähr 10 Tage. Ich bevorzuge ein ruhiges Gästehaus mit Frühstück.', isCorrect: true, feedback: '✓ Excellent ! "Ungefähr" = environ. "Bevorzugen" = préférer. "Gästehaus" = maison d\'hôtes. Vocabulaire riche et précis.' },
        { text: 'Ich bleibe lang. Hotel oder nicht Hotel.', isCorrect: false, feedback: '✗ Trop vague. Précisez la durée ("eine Woche", "zehn Tage") et le type d\'hébergement. Utilisez "entweder... oder..." : "entweder ein Hotel oder ein Hostel."' },
      ],
    },
    {
      tutorMessage: 'Perfekt! Was möchtest du unbedingt sehen oder machen? Hast du besondere Interessen?',
      tutorNote: '"Unbedingt" = absolument. "Besondere Interessen" = intérêts particuliers. Utilisez "Ich interessiere mich für..."',
      options: [
        { text: 'Ich interessiere mich sehr für Geschichte. Ich würde gerne Schloss Neuschwanstein besichtigen.', isCorrect: true, feedback: '✓ Bravo ! "Sich interessieren für" = s\'intéresser à (+ accusatif). "Besichtigen" = visiter (un lieu). Excellent !' },
        { text: 'Am liebsten würde ich wandern gehen und die Natur genießen — ich bin großer Naturliebhaber.', isCorrect: true, feedback: '✓ Parfait ! "Wandern gehen" = faire de la randonnée. "Genießen" = apprécier/savourer. "Naturliebhaber" = amoureux de la nature. Très riche !' },
        { text: 'Ich will Essen essen und Fotos machen.', isCorrect: false, feedback: '✗ "Essen essen" est répétitif — dites "bayerische Spezialitäten probieren" (goûter des spécialités bavaroises). Ajoutez du détail à votre réponse.' },
      ],
    },
    {
      tutorMessage: 'Wunderbar! Sollen wir auch ein Budget festlegen? Wie viel möchtest du ungefähr ausgeben?',
      tutorNote: '"Festlegen" = fixer/établir. "Ausgeben" = dépenser. Utilisez "Ich würde... ausgeben" ou "Mein Budget beträgt..."',
      options: [
        { text: 'Mein Budget beträgt ungefähr 800 Euro, ohne Flug. Das sollte für eine Woche reichen.', isCorrect: true, feedback: '✓ Excellent ! "Betragen" = s\'élever à (pour un montant). "Ohne Flug" = hors vol. "Reichen" = suffire. Très professionnel !' },
        { text: 'Ich würde etwa 100 Euro pro Tag ausgeben wollen — das wäre für mich angemessen.', isCorrect: true, feedback: '✓ Parfait ! Double Konjunktiv II ("würde... wollen") pour exprimer une préférence polie. "Angemessen" = approprié/raisonnable.' },
        { text: 'Nicht viel Geld. Was kostet Bayern?', isCorrect: false, feedback: '✗ Vague et peu naturel. "Was kostet Bayern?" n\'a pas de sens. Demandez plutôt : "Was würde das ungefähr kosten?" et donnez un budget estimatif.' },
      ],
    },
  ],

  'b2-jobinterview': [
    {
      tutorMessage: 'Guten Tag! Schön, dass Sie gekommen sind. Können Sie sich bitte kurz vorstellen?',
      tutorNote: 'Présentez votre parcours de façon structurée : formation → expérience → motivation.',
      options: [
        { text: 'Guten Tag! Ich heiße Marie Durand, ich komme aus Frankreich und habe Informatik studiert. Seit drei Jahren arbeite ich als Softwareentwicklerin in Paris.', isCorrect: true, feedback: '✓ Excellente présentation ! Structure claire : identité → formation → expérience. "Seit" + datif pour la durée. Très professionnel !' },
        { text: 'Ja, ich bin Marie. Ich habe studiert und dann gearbeitet in verschiedenen Firmen.', isCorrect: false, feedback: '✗ Trop vague pour un entretien. Précisez : votre domaine d\'études, les entreprises (ou leur secteur), et vos responsabilités. L\'entretien exige de la précision.' },
        { text: 'Ich heiße Marie und ich mag diese Stelle sehr gerne haben.', isCorrect: false, feedback: '✗ Commencez par vous présenter (parcours), pas par votre désir pour le poste. "Mag... gerne haben" est incorrect : dites "Ich würde diese Stelle gerne bekommen" ou mieux, attendez la question sur la motivation.' },
      ],
    },
    {
      tutorMessage: 'Sehr gut! Warum haben Sie sich für diese Stelle beworben? Was interessiert Sie an unserem Unternehmen?',
      tutorNote: 'Montrez que vous vous êtes renseigné sur l\'entreprise. Utilisez des connecteurs : "Außerdem", "Darüber hinaus", "Vor allem".',
      options: [
        { text: 'Ich habe mich beworben, weil Ihr Unternehmen für seine Innovationskraft bekannt ist. Vor allem interessiert mich die internationale Ausrichtung Ihrer Projekte.', isCorrect: true, feedback: '✓ Parfait ! "Innovationskraft" = capacité d\'innovation. "Vor allem" = surtout/avant tout. "Ausrichtung" = orientation. Réponse de haut niveau !' },
        { text: 'Diese Stelle passt gut zu meinen Qualifikationen und ich möchte meine Karriere in Deutschland weiterentwickeln.', isCorrect: true, feedback: '✓ Excellent ! "Passen zu" = correspondre à. "Weiterentwickeln" = développer davantage. Motivation claire et professionnelle.' },
        { text: 'Ich brauche Arbeit und Berlin ist eine schöne Stadt.', isCorrect: false, feedback: '✗ Cette réponse est honnête mais inappropriée. Ne parlez pas de vos besoins personnels — mettez en avant la valeur ajoutée que vous apportez à l\'entreprise.' },
      ],
    },
    {
      tutorMessage: 'Interessant! Was sind Ihrer Meinung nach Ihre größten Stärken — und auch Ihre Schwächen?',
      tutorNote: 'Classique en entretien ! Pour les faiblesses, choisissez quelque chose de mineur et montrez comment vous l\'améliorez.',
      options: [
        { text: 'Meine größte Stärke ist meine analytische Denkweise. Als Schwäche würde ich nennen, dass ich manchmal zu perfektionistisch bin — ich arbeite aber aktiv daran.', isCorrect: true, feedback: '✓ Réponse d\'entretien parfaite ! "Denkweise" = façon de penser. "Würde nennen" = Konjunktiv II poli. La stratégie "faiblesse + amélioration" est idéale !' },
        { text: 'Ich bin sehr teamfähig und lernbereit. Manchmal habe ich Schwierigkeiten mit sehr kurzen Fristen, aber ich priorisiere gut.', isCorrect: true, feedback: '✓ Excellent ! "Teamfähig" = capable de travailler en équipe. "Lernbereit" = prêt à apprendre. "Fristen" = délais. Très professionnel !' },
        { text: 'Ich habe keine Schwächen. Ich bin sehr gut in allem.', isCorrect: false, feedback: '✗ Personne ne croira cela et cela donnera une mauvaise impression. Montrez plutôt votre capacité d\'auto-critique : "Ich arbeite noch daran, meine Präsentationsfähigkeiten zu verbessern."' },
      ],
    },
    {
      tutorMessage: 'Sehr überzeugend. Haben Sie noch Fragen an uns?',
      tutorNote: 'Toujours poser 1-2 questions ! Cela montre votre intérêt. Évitez de demander le salaire en premier.',
      options: [
        { text: 'Ja, gerne! Wie würde ein typischer Arbeitstag in dieser Position aussehen?', isCorrect: true, feedback: '✓ Question idéale ! "Wie würde... aussehen" = Konjunktiv II pour une question polie. Montre votre intérêt concret pour le poste.' },
        { text: 'Welche Möglichkeiten zur Weiterbildung bietet das Unternehmen seinen Mitarbeitern?', isCorrect: true, feedback: '✓ Excellent ! "Weiterbildung" = formation continue. "Mitarbeiter" = employés. Question qui montre votre ambition à long terme. Très apprécié !' },
        { text: 'Wie viel Gehalt bekomme ich?', isCorrect: false, feedback: '✗ Demander le salaire en première question est mal perçu. Attendez que l\'employeur l\'aborde, ou posez-le en dernière question après avoir montré votre intérêt pour le poste.' },
      ],
    },
  ],

  'b2-klimawandel': [
    {
      tutorMessage: 'Der Klimawandel ist eine der größten Herausforderungen unserer Zeit. Welche Maßnahmen halten Sie für am effektivsten?',
      tutorNote: '"Maßnahmen" = mesures. "Halten für" = considérer comme. Structurez avec des connecteurs logiques.',
      options: [
        { text: 'Meiner Ansicht nach sind erneuerbare Energien am effektivsten, denn sie reduzieren CO₂-Emissionen langfristig und schaffen gleichzeitig neue Arbeitsplätze.', isCorrect: true, feedback: '✓ Argument de niveau B2 ! "Meiner Ansicht nach" = à mon avis. "Langfristig" = à long terme. "Gleichzeitig" = en même temps. Double argument efficace !' },
        { text: 'Ich finde, dass individuelle Maßnahmen wichtig sind, aber ohne politischen Willen reichen sie nicht aus.', isCorrect: true, feedback: '✓ Excellent ! "Politischer Wille" = volonté politique. "Ausreichen" = suffire. Nuance importante : individuel vs systémique. Parfait !' },
        { text: 'Klimawandel ist sehr schlecht. Wir müssen etwas tun.', isCorrect: false, feedback: '✗ Trop vague pour une discussion B2. Proposez des mesures concrètes : "Wir müssen in erneuerbare Energien investieren und Subventionen für fossile Brennstoffe abschaffen."' },
      ],
    },
    {
      tutorMessage: 'Interessant. Manche sagen, wirtschaftliches Wachstum und Klimaschutz seien unvereinbar. Was meinen Sie?',
      tutorNote: '"Unvereinbar" = incompatible. "Manche sagen... seien" = Konjunktiv I pour le discours indirect. Réfutez ou défendez cette idée.',
      options: [
        { text: 'Zwar gab es früher Widersprüche, aber heute zeigen Länder wie Deutschland und Dänemark, dass grünes Wachstum möglich ist.', isCorrect: true, feedback: '✓ Parfait ! Structure "Zwar..., aber..." pour concéder puis contredire. "Widerspruch" = contradiction. Argumentation par l\'exemple — très efficace !' },
        { text: 'Ich widerspreche dieser These. Die Kreislaufwirtschaft beweist, dass Nachhaltigkeit und Wachstum sich nicht ausschließen.', isCorrect: true, feedback: '✓ Excellent ! "Widersprechen" = contredire. "Kreislaufwirtschaft" = économie circulaire. "Sich ausschließen" = s\'exclure mutuellement. Niveau C1 !' },
        { text: 'Nein, das stimmt nicht. Klimaschutz und Wirtschaft können zusammen sein.', isCorrect: false, feedback: '✗ L\'idée est correcte mais la formulation est trop simple pour un B2. Utilisez "vereinbar sein" et citez des exemples : "Länder wie... beweisen, dass..."' },
      ],
    },
    {
      tutorMessage: 'Überzeugendes Argument! Was können Einzelpersonen tun, und was ist eher Aufgabe der Politik?',
      tutorNote: 'Distinguez les responsabilités individuelle et collective. "Eher" = plutôt. "Aufgabe" = mission/responsabilité.',
      options: [
        { text: 'Einzelpersonen können ihren CO₂-Fußabdruck reduzieren — weniger fliegen, veganer essen. Aber strukturelle Änderungen, wie CO₂-Besteuerung, müssen von der Politik kommen.', isCorrect: true, feedback: '✓ Remarquable ! "CO₂-Fußabdruck" = empreinte carbone. "Besteuerung" = taxation. La distinction individuel/structurel est exactement ce qu\'il faut. Bravo !' },
        { text: 'Beide Ebenen sind entscheidend. Ohne Bürgerengagement fehlt der politische Druck, und ohne politische Rahmenbedingungen bleibt individuelles Handeln wirkungslos.', isCorrect: true, feedback: '✓ Superbe synthèse ! "Entscheidend" = décisif. "Rahmenbedingungen" = conditions-cadres. "Wirkungslos" = sans effet. Niveau C1 atteint !' },
        { text: 'Die Politik muss alles machen. Einzelpersonen können nichts tun.', isCorrect: false, feedback: '✗ Position trop extrême. Une argumentation nuancée est plus convaincante : reconnaissez le rôle des deux acteurs et expliquez leurs limites respectives.' },
      ],
    },
    {
      tutorMessage: 'Zum Abschluss: Wie optimistisch sind Sie, was die Zukunft des Klimas betrifft?',
      tutorNote: '"Optimistisch" = optimiste. "Was... betrifft" = en ce qui concerne. Exprimez une opinion nuancée avec "einerseits... andererseits".',
      options: [
        { text: 'Ich bin vorsichtig optimistisch. Einerseits zeigen technologische Fortschritte Hoffnung, andererseits besteht die Gefahr, dass Maßnahmen zu spät kommen.', isCorrect: true, feedback: '✓ Conclusion parfaite ! "Vorsichtig optimistisch" = prudemment optimiste. "Fortschritt" = progrès. "Zu spät kommen" = arriver trop tard. Nuance excellente !' },
        { text: 'Ich glaube, dass die junge Generation entscheidend sein wird. Bewegungen wie Fridays for Future zeigen, dass Wandel möglich ist.', isCorrect: true, feedback: '✓ Très bien ! Référence concrète et pertinente. "Wandel" = changement. "Zeigen, dass" + subordonnée. Conclusion engagée et structurée.' },
        { text: 'Ich bin nicht optimistisch. Alles ist verloren.', isCorrect: false, feedback: '✗ Même si vous êtes pessimiste, argumentez ! "Trotz mancher Bemühungen befürchte ich, dass..." est bien plus convaincant qu\'une affirmation sans fondement.' },
      ],
    },
  ],

  'c1-literatur': [
    {
      tutorMessage: 'Haben Sie Kafkas "Die Verwandlung" gelesen? Wie interpretieren Sie die Verwandlung Gregor Samsas?',
      tutorNote: 'Utilisez des constructions nominales (C1) et un vocabulaire d\'analyse littéraire.',
      options: [
        { text: 'Die Verwandlung symbolisiert meiner Interpretation nach die Entfremdung des modernen Menschen von Arbeit und Familie — Gregor verliert seinen Nutzwert und wird isoliert.', isCorrect: true, feedback: '✓ Analyse de niveau C1 ! "Entfremdung" = aliénation. "Nutzwert" = valeur utilitaire. Construction nominale parfaite. Référence au contexte socio-économique de Kafka.' },
        { text: 'Man könnte argumentieren, dass die Metamorphose eine psychologische Realität darstellt — Gregors Gefühl, seiner Familie zur Last zu fallen.', isCorrect: true, feedback: '✓ Excellente lecture psychologique ! "Man könnte argumentieren" = formule académique parfaite. "Zur Last fallen" = être un fardeau. Interprétation profonde !' },
        { text: 'Gregor wird zu einem Insekt. Das ist sehr seltsam. Kafka war verrückt.', isCorrect: false, feedback: '✗ Ce type de commentaire est inapproprié dans une discussion littéraire. Analysez le symbolisme : "Die Insektenmetapher steht für..." ou "Die Verwandlung kann als Metapher für... gelesen werden."' },
      ],
    },
    {
      tutorMessage: 'Sehr tiefgründig! Welche Rolle spielt die Familie in Kafkas Werk? Und was sagt das über die gesellschaftliche Situation zu Kafkas Zeit?',
      tutorNote: '"Tiefgründig" = profond/perspicace. Reliez le texte au contexte historique et social.',
      options: [
        { text: 'Die Familie verkörpert bei Kafka gesellschaftliche Zwänge und Leistungsanforderungen. Im Kontext der Industrialisierung spiegelt sie die Entmenschlichung durch ökonomische Abhängigkeit wider.', isCorrect: true, feedback: '✓ Analyse magistrale ! "Verkörpern" = incarner. "Zwänge" = contraintes. "Widerspiegeln" = refléter. Lien texte-contexte parfaitement établi. Niveau C1/C2 !' },
        { text: 'Kafka zeigt, wie familiäre Bindungen unter wirtschaftlichem Druck zerbrechen können — eine Problematik, die auch heute noch aktuell ist.', isCorrect: true, feedback: '✓ Excellent ! "Zerbrechen" = se briser. "Aktuell" = actuel/pertinent. Le lien avec le présent enrichit l\'analyse. Très bien construit !' },
        { text: 'Die Familie ist nicht nett zu Gregor. Das finde ich traurig.', isCorrect: false, feedback: '✗ Réaction émotionnelle valide, mais insuffisante pour une analyse C1. Transformez-la : "Die distanzierte Reaktion der Familie verdeutlicht, wie Gregor nur als Versorger wahrgenommen wird, was Kafkas Kritik an..."' },
      ],
    },
    {
      tutorMessage: 'Brillant! Gibt es Parallelen zu anderen Werken — deutsch oder international — die Sie ziehen könnten?',
      tutorNote: '"Parallelen ziehen" = établir des parallèles. Comparez avec d\'autres œuvres que vous connaissez.',
      options: [
        { text: 'Man könnte Parallelen zu Büchners "Woyzeck" ziehen: beide Protagonisten sind Opfer gesellschaftlicher Strukturen, die sie dehumanisieren.', isCorrect: true, feedback: '✓ Comparaison littéraire de haut niveau ! "Protagonist" = protagoniste. "Dehumanisieren" = déshumaniser. "Man könnte... ziehen" = formule académique parfaite. Excellent !' },
        { text: 'Mich erinnert Kafkas Werk an Camus\' "L\'Étranger" — beide Protagonisten sind Außenseiter, die von ihrer Umgebung nicht verstanden werden.', isCorrect: true, feedback: '✓ Comparaison franco-allemande pertinente ! "Außenseiter" = marginal/outsider. "Erinnern an" = faire penser à. Montrer une culture littéraire étendue est très apprécié.' },
        { text: 'Ich kenne kein anderes Buch wie dieses.', isCorrect: false, feedback: '✗ Si vous n\'avez pas d\'exemple précis, guidez la réflexion : "Thematisch ließe sich eine Verbindung zu... herstellen, auch wenn ich das nicht direkt mit einem Werk belegen kann." Ne capitulz pas, engagez-vous !' },
      ],
    },
    {
      tutorMessage: 'Wunderbar! Wenn Sie "Die Verwandlung" in einem einzigen Satz zusammenfassen müssten — welcher wäre das?',
      tutorNote: 'Exercice de synthèse : une phrase élégante, denses et précise. Utilisez une construction nominale ou une métaphore.',
      options: [
        { text: '"Die Verwandlung" ist eine Parabel über die Entfremdung des Individuums in einer Gesellschaft, die den Menschen auf seinen wirtschaftlichen Nutzen reduziert.', isCorrect: true, feedback: '✓ Phrase de synthèse parfaite ! "Parabel" = parabole. "Auf... reduzieren" = réduire à. Concis, précis, analytique. C\'est exactement le niveau C1 attendu !' },
        { text: 'Kafka zeigt, wie ein Mensch aufhört, Mensch zu sein, sobald er aufhört, nützlich zu sein.', isCorrect: true, feedback: '✓ Magnifique ! Structure parallèle et chiasmatique. "Sobald" = dès que. Formulation élégante et mémorable. C\'est de la critique littéraire de qualité !' },
        { text: 'Das Buch handelt von einem Mann, der ein Insekt wird und dann stirbt.', isCorrect: false, feedback: '✗ Correct factuellement, mais c\'est un résumé, pas une interprétation. Pour C1 : "Die Erzählung ist eine Metapher für..." — allez au-delà de la surface narrative.' },
      ],
    },
  ],

  'c2-philosophie': [
    {
      tutorMessage: 'Kants kategorischer Imperativ — ist er wirklich universell anwendbar? Wie steht es mit kulturellen Unterschieden?',
      tutorNote: 'Niveau C2 : constructions complexes, réfutation élégante, synthèse. "Man könnte einwenden, dass..." est votre outil principal.',
      options: [
        { text: 'Kants Imperativ beansprucht universelle Geltung, doch man könnte einwenden, dass er selbst kulturell bedingt ist — er spiegelt ein aufklärerisches, westliches Vernunftideal wider, das nicht überall geteilt wird.', isCorrect: true, feedback: '✓ Critique philosophique de niveau C2 ! "Beanspruchen" = prétendre à. "Geltung" = validité. "Aufklärerisch" = des Lumières. Déconstruction culturelle sophistiquée !' },
        { text: 'Ungeachtet kultureller Variationen ließe sich argumentieren, dass der Imperativ eine formale Struktur bietet, die transkulturell anwendbar ist, auch wenn der Inhalt variiert.', isCorrect: true, feedback: '✓ Nuance philosophique remarquable ! "Ungeachtet" = nonobstant. "Ließe sich argumentieren" = Konjunktiv II passif très élégant. Distinction forme/contenu — excellente !' },
        { text: 'Kant hatte recht. Der Imperativ ist universell. Fertig.', isCorrect: false, feedback: '✗ Affirmer sans argumenter n\'est pas de la philosophie. Même si vous défendez Kant, vous devez argumenter : "Kants Stärke liegt darin, dass... Zwar könnte man einwenden..., doch..."' },
      ],
    },
    {
      tutorMessage: 'Ausgezeichnet! Hegel würde Kant vorwerfen, die Dialektik zu vernachlässigen. Wie sehen Sie das Verhältnis zwischen Kants Formalismus und Hegels historischer Dialektik?',
      tutorNote: '"Vorwerfen" = reprocher. "Vernachlässigen" = négliger. Comparez deux systèmes philosophiques.',
      options: [
        { text: 'Während Kant eine zeitlose, formale Moralstruktur entwirft, begreift Hegel Moral als historisch evolvierende Größe. Hegels Dialektik erlaubt, den Widerspruch zwischen Norm und Realität produktiv zu denken.', isCorrect: true, feedback: '✓ Analyse comparative de niveau C2 ! "Entwerfen" = concevoir/esquisser. "Begreifen" = concevoir/saisir. "Produktiv denken" = penser de façon productive. Remarquable !' },
        { text: 'Man könnte sagen, dass Kant und Hegel sich nicht widersprechen, sondern ergänzen: Kant gibt das Gerüst, Hegel den geschichtlichen Inhalt.', isCorrect: true, feedback: '✓ Synthèse dialectique élégante ! "Gerüst" = échafaudage/structure. "Sich ergänzen" = se compléter. Dépasser l\'opposition pour trouver une synthèse — c\'est du niveau C2 !' },
        { text: 'Ich verstehe Hegel nicht so gut. Kant ist einfacher.', isCorrect: false, feedback: '✗ L\'aveu d\'ignorance sans tentative est à éviter. Formulez votre incertitude en philosophe : "Hegels System ist zugegeben komplex, doch soweit ich es verstehe, kritisiert er Kants..." — engagez-vous même avec des réserves.' },
      ],
    },
    {
      tutorMessage: 'Tiefgründig! Letzte Frage: Ist die Philosophie heute noch relevant, oder ist sie von den Wissenschaften überholt worden?',
      tutorNote: '"Überholt" = dépassé. Question ouverte — montrez votre capacité à défendre une position avec nuance.',
      options: [
        { text: 'Die Wissenschaften beantworten das "Wie", die Philosophie das "Warum" und "Wozu". Gerade angesichts von KI-Ethik und Biotechnologie ist philosophische Reflexion unentbehrlicher denn je.', isCorrect: true, feedback: '✓ Argumentation brillante ! "Unentbehrlich" = indispensable. "Denn je" = que jamais. La distinction How/Why/Wherefore est philosophiquement solide. Excellent C2 !' },
        { text: 'Philosophie und Wissenschaft sind keine Konkurrenten, sondern komplementäre Erkenntnisweisen — die eine ohne die andere bleibt blind oder leer, um Kant zu paraphrasieren.', isCorrect: true, feedback: '✓ Paraphrase kantienne magnifique ("Gedanken ohne Inhalt sind leer, Anschauungen ohne Begriffe sind blind"). "Erkenntnisweise" = mode de connaissance. C2 accompli !' },
        { text: 'Nein, die Wissenschaft hat die Philosophie ersetzt. Philosophie ist veraltet.', isCorrect: false, feedback: '✗ Position réductrice. Même si vous le pensez, argumentez : "Man könnte behaupten, dass empirische Wissenschaften viele metaphysische Fragen beantwortet haben. Dennoch bleiben normative Fragen..." Défendez votre thèse.' },
      ],
    },
    {
      tutorMessage: 'Beeindruckend! Sie haben heute auf sehr hohem Niveau argumentiert. Haben Sie abschließend noch eine eigene philosophische These, die Sie vertreten?',
      tutorNote: '"Beeindruckend" = impressionnant. Formulez une thèse personnelle — osez une position originale !',
      options: [
        { text: 'Meine These: Die größte Herausforderung unserer Zeit ist nicht technologischer, sondern ethischer Natur — und genau deshalb brauchen wir Philosophie mehr als je zuvor.', isCorrect: true, feedback: '✓ Thèse forte et personnelle ! "Ethischer Natur" = de nature éthique. "Genau deshalb" = c\'est précisément pourquoi. Structure rhétorique impeccable. Bravo !' },
        { text: 'Ich vertrete die These, dass wahre Freiheit nur im Bewusstsein der eigenen Grenzen besteht — in diesem Sinne ist Philosophie selbst eine Übung in Bescheidenheit.', isCorrect: true, feedback: '✓ Thèse philosophique originale et profonde ! "Bescheidenheit" = humilité. "In diesem Sinne" = en ce sens. Formulation digne d\'un essai académique. Niveau C2 atteint !' },
        { text: 'Ich habe keine eigene These. Ich stimme mit allem überein.', isCorrect: false, feedback: '✗ La philosophie exige une position propre ! Même provisoire : "Wenn ich eine These wagen müsste, würde ich sagen, dass..." — Kant lui-même exigeait qu\'on ose penser par soi-même : Sapere aude !' },
      ],
    },
  ],
};

// ── Types ──────────────────────────────────────────────────────────────────

const LEVELS: LevelId[] = ['A1', 'A2', 'B1', 'B2', 'C1', 'C2'];

type TutorPhase = 'select' | 'dialogue' | 'result';

interface TurnState {
  turnIndex: number;
  selectedOption: number | null;
  revealed: boolean;
  score: number;
}

// ── Main Component ─────────────────────────────────────────────────────────

export default function IA() {
  const [filterLevel, setFilterLevel] = useState<LevelId | 'all'>('all');
  const [selected, setSelected] = useState<AIScenario | null>(null);
  const [phase, setPhase] = useState<TutorPhase>('select');

  const filtered = filterLevel === 'all'
    ? AI_SCENARIOS
    : AI_SCENARIOS.filter(s => s.level === filterLevel);

  const handleSelectScenario = (scenario: AIScenario) => {
    setSelected(scenario);
    setPhase('dialogue');
  };

  const handleBack = () => {
    setSelected(null);
    setPhase('select');
  };

  return (
    <Layout>
      <div className="container py-8 lg:py-12">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-2 mb-1">
            <Zap size={14} className="text-violet-400" />
            <span className="data-label">Tuteur de conversation</span>
          </div>
          <div className="flex items-center gap-3 mb-2">
            <GraduationCap size={24} className="text-violet-400" />
            <h1 className="font-display text-2xl lg:text-3xl font-bold">Tuteur interactif</h1>
          </div>
          <p className="text-muted-foreground">
            {AI_SCENARIOS.length} scénarios guidés A1–C2 — choisissez vos réponses et recevez un feedback immédiat.
          </p>
        </div>

        {phase === 'select' && (
          <>
            {/* Filters */}
            <div className="flex flex-wrap gap-2 mb-8">
              <button
                onClick={() => setFilterLevel('all')}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${filterLevel === 'all' ? 'bg-primary text-primary-foreground' : 'bg-card border border-border text-muted-foreground hover:text-foreground'}`}
              >
                Tous
              </button>
              {LEVELS.map(level => {
                const c = LEVEL_COLORS[level];
                const count = AI_SCENARIOS.filter(s => s.level === level).length;
                if (count === 0) return null;
                return (
                  <button
                    key={level}
                    onClick={() => setFilterLevel(level)}
                    className={`px-4 py-2 rounded-lg text-sm font-mono font-bold transition-all ${filterLevel === level ? `${c.bg} border ${c.border} ${c.text}` : 'bg-card border border-border text-muted-foreground hover:text-foreground'}`}
                  >
                    {level} ({count})
                  </button>
                );
              })}
            </div>

            {/* Scenarios grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {filtered.map(scenario => {
                const colors = LEVEL_COLORS[scenario.level];
                const turns = DIALOGUES[scenario.id]?.length ?? 0;
                return (
                  <button
                    key={scenario.id}
                    onClick={() => handleSelectScenario(scenario)}
                    className={`group text-left rounded-xl border ${colors.border} bg-card p-5 hover:scale-[1.02] transition-all duration-200 panel-hud circuit-corner`}
                  >
                    <div className="flex items-center gap-2 mb-3">
                      <span className={`text-xs font-mono font-bold px-2 py-0.5 rounded-full border ${colors.bg} ${colors.text} ${colors.border}`}>
                        {scenario.level}
                      </span>
                      <span className="text-[11px] text-muted-foreground font-mono ml-auto">{turns} échanges</span>
                    </div>
                    <h3 className="font-display font-semibold text-sm text-foreground mb-1">{scenario.title}</h3>
                    <p className="text-[11px] font-mono text-muted-foreground mb-2">{scenario.titleDe}</p>
                    <p className="text-xs text-muted-foreground leading-relaxed line-clamp-2">{scenario.description}</p>
                    <div className="flex items-center gap-1.5 mt-4 text-xs text-muted-foreground/60 group-hover:text-primary transition-colors">
                      <MessageSquare size={12} />
                      <span>Commencer le dialogue</span>
                      <ChevronRight size={12} className="ml-auto" />
                    </div>
                  </button>
                );
              })}
            </div>
          </>
        )}

        {phase === 'dialogue' && selected && (
          <TutorDialogue
            scenario={selected}
            onBack={handleBack}
            onFinish={() => setPhase('result')}
          />
        )}

        {phase === 'result' && selected && (
          <ResultScreen
            scenario={selected}
            onReplay={() => setPhase('dialogue')}
            onBack={handleBack}
          />
        )}
      </div>
    </Layout>
  );
}

// ── Tutor Dialogue ─────────────────────────────────────────────────────────

function TutorDialogue({
  scenario,
  onBack,
  onFinish,
}: {
  scenario: AIScenario;
  onBack: () => void;
  onFinish: (score: number, total: number) => void;
}) {
  const turns = DIALOGUES[scenario.id] ?? [];
  const colors = LEVEL_COLORS[scenario.level];

  const [turnIndex, setTurnIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [revealed, setRevealed] = useState(false);
  const [score, setScore] = useState(0);
  const [history, setHistory] = useState<{ tutor: string; user: string; correct: boolean }[]>([]);

  const currentTurn = turns[turnIndex];
  const progress = ((turnIndex) / turns.length) * 100;

  const handleSelect = (idx: number) => {
    if (revealed) return;
    setSelectedOption(idx);
    setRevealed(true);
    if (currentTurn.options[idx].isCorrect) {
      setScore(s => s + 1);
    }
  };

  const handleNext = () => {
    if (!currentTurn || selectedOption === null) return;
    const opt = currentTurn.options[selectedOption];
    setHistory(h => [...h, {
      tutor: currentTurn.tutorMessage,
      user: opt.text,
      correct: opt.isCorrect,
    }]);

    if (turnIndex + 1 >= turns.length) {
      const finalScore = score + (opt.isCorrect ? 0 : 0); // already added on reveal
      onFinish(score, turns.length);
    } else {
      setTurnIndex(i => i + 1);
      setSelectedOption(null);
      setRevealed(false);
    }
  };

  if (!currentTurn) return null;

  return (
    <div className="max-w-2xl mx-auto">
      {/* Back + Progress */}
      <div className="flex items-center gap-3 mb-6">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors shrink-0"
        >
          <ArrowLeft size={16} />
          Retour
        </button>
        <div className="flex-1 h-1.5 bg-muted rounded-full overflow-hidden">
          <div
            className="h-full bg-primary transition-all duration-500 rounded-full"
            style={{ width: `${progress}%` }}
          />
        </div>
        <span className="text-xs font-mono text-muted-foreground shrink-0">
          {turnIndex + 1}/{turns.length}
        </span>
      </div>

      {/* Scenario badge */}
      <div className="flex items-center gap-2 mb-4">
        <span className={`text-xs font-mono font-bold px-2.5 py-0.5 rounded-full border ${colors.bg} ${colors.text} ${colors.border}`}>
          {scenario.level}
        </span>
        <span className="text-sm font-display font-semibold text-foreground">{scenario.title}</span>
        <span className="text-xs text-muted-foreground ml-auto">Score : {score}/{turnIndex}</span>
      </div>

      {/* History */}
      {history.length > 0 && (
        <div className="mb-4 space-y-2 opacity-60">
          {history.map((h, i) => (
            <div key={i} className="space-y-1">
              <div className="flex gap-2">
                <div className="w-7 h-7 rounded-full bg-violet-500/20 border border-violet-400/30 flex items-center justify-center shrink-0 mt-0.5">
                  <GraduationCap size={12} className="text-violet-400" />
                </div>
                <div className="bg-card border border-border rounded-2xl rounded-tl-sm px-4 py-2.5 text-sm text-muted-foreground flex-1">
                  {h.tutor}
                </div>
              </div>
              <div className="flex gap-2 flex-row-reverse">
                <div className={`w-7 h-7 rounded-full flex items-center justify-center shrink-0 mt-0.5 ${h.correct ? 'bg-emerald-500/20 border border-emerald-400/30' : 'bg-red-500/20 border border-red-400/30'}`}>
                  {h.correct
                    ? <CheckCircle2 size={12} className="text-emerald-400" />
                    : <XCircle size={12} className="text-red-400" />
                  }
                </div>
                <div className={`rounded-2xl rounded-tr-sm px-4 py-2.5 text-sm flex-1 text-right border ${h.correct ? 'bg-emerald-500/10 border-emerald-400/20 text-emerald-300' : 'bg-red-500/10 border-red-400/20 text-red-300'}`}>
                  {h.user}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Current tutor message */}
      <div className="flex gap-3 mb-4">
        <div className="w-9 h-9 rounded-full bg-violet-500/20 border border-violet-400/30 flex items-center justify-center shrink-0 mt-1">
          <GraduationCap size={16} className="text-violet-400" />
        </div>
        <div className="bg-card border border-violet-400/20 rounded-2xl rounded-tl-sm px-5 py-4 flex-1">
          <p className="text-sm text-foreground leading-relaxed">{currentTurn.tutorMessage}</p>
        </div>
      </div>

      {/* Grammar note */}
      {currentTurn.tutorNote && (
        <div className="ml-12 mb-4 flex items-start gap-2 p-3 rounded-lg bg-amber-500/5 border border-amber-400/20">
          <Lightbulb size={13} className="text-amber-400 mt-0.5 shrink-0" />
          <p className="text-[11px] text-amber-300/80 leading-relaxed">{currentTurn.tutorNote}</p>
        </div>
      )}

      {/* Options */}
      <div className="ml-12 space-y-2 mb-4">
        {currentTurn.options.map((opt, idx) => {
          const isSelected = selectedOption === idx;
          const isCorrect = opt.isCorrect;

          let cls = 'bg-card border border-border text-muted-foreground hover:border-primary/50 hover:text-foreground cursor-pointer';
          if (revealed && isSelected && isCorrect) cls = 'bg-emerald-500/10 border-emerald-400/50 text-emerald-300 cursor-default';
          if (revealed && isSelected && !isCorrect) cls = 'bg-red-500/10 border-red-400/50 text-red-300 cursor-default';
          if (revealed && !isSelected && isCorrect) cls = 'bg-emerald-500/5 border-emerald-400/20 text-emerald-400/60 cursor-default';
          if (revealed && !isSelected && !isCorrect) cls = 'bg-card border border-border text-muted-foreground/40 cursor-default';

          return (
            <div key={idx}>
              <button
                onClick={() => handleSelect(idx)}
                disabled={revealed}
                className={`w-full text-left rounded-xl px-4 py-3 text-sm transition-all duration-200 flex items-start gap-3 ${cls}`}
              >
                <span className={`mt-0.5 font-mono text-xs shrink-0 w-5 h-5 rounded-full flex items-center justify-center border ${
                  revealed && isSelected && isCorrect ? 'border-emerald-400 text-emerald-400' :
                  revealed && isSelected && !isCorrect ? 'border-red-400 text-red-400' :
                  revealed && !isSelected && isCorrect ? 'border-emerald-400/40 text-emerald-400/40' :
                  'border-border text-muted-foreground'
                }`}>
                  {String.fromCharCode(65 + idx)}
                </span>
                <span className="leading-relaxed">{opt.text}</span>
                {revealed && isCorrect && <CheckCircle2 size={15} className="text-emerald-400 ml-auto shrink-0 mt-0.5" />}
                {revealed && isSelected && !isCorrect && <XCircle size={15} className="text-red-400 ml-auto shrink-0 mt-0.5" />}
              </button>

              {/* Feedback */}
              {revealed && isSelected && (
                <div className={`mt-1.5 ml-8 px-4 py-2.5 rounded-lg text-xs leading-relaxed border ${
                  isCorrect
                    ? 'bg-emerald-500/8 border-emerald-400/15 text-emerald-300/90'
                    : 'bg-red-500/8 border-red-400/15 text-red-300/90'
                }`}>
                  {opt.feedback}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Next button */}
      {revealed && (
        <div className="ml-12">
          <button
            onClick={handleNext}
            className="flex items-center gap-2 px-5 py-2.5 bg-primary text-primary-foreground rounded-lg text-sm font-medium hover:opacity-90 transition-opacity"
          >
            {turnIndex + 1 >= turns.length ? (
              <>
                <Trophy size={15} />
                Voir les résultats
              </>
            ) : (
              <>
                Continuer
                <ChevronRight size={15} />
              </>
            )}
          </button>
        </div>
      )}
    </div>
  );
}

// ── Result Screen ──────────────────────────────────────────────────────────

function ResultScreen({
  scenario,
  onReplay,
  onBack,
}: {
  scenario: AIScenario;
  onReplay: () => void;
  onBack: () => void;
}) {
  const turns = DIALOGUES[scenario.id] ?? [];
  const colors = LEVEL_COLORS[scenario.level];

  // Retrieve final score from session storage workaround: just show stars based on completion
  const totalTurns = turns.length;

  return (
    <div className="max-w-lg mx-auto text-center">
      <button
        onClick={onBack}
        className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors mb-8"
      >
        <ArrowLeft size={16} />
        Retour aux scénarios
      </button>

      {/* Trophy */}
      <div className="w-20 h-20 rounded-2xl bg-amber-500/15 border border-amber-400/30 flex items-center justify-center mx-auto mb-6">
        <Trophy size={36} className="text-amber-400" />
      </div>

      <h2 className="font-display text-2xl font-bold text-foreground mb-2">Dialogue terminé !</h2>
      <p className="text-muted-foreground mb-2">Vous avez complété le scénario :</p>

      <div className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-full border ${colors.bg} ${colors.border} mb-6`}>
        <span className={`text-xs font-mono font-bold ${colors.text}`}>{scenario.level}</span>
        <span className="text-sm font-display font-semibold text-foreground">{scenario.title}</span>
      </div>

      {/* Stars */}
      <div className="flex items-center justify-center gap-1 mb-6">
        {[1, 2, 3].map(i => (
          <Star key={i} size={28} className="text-amber-400 fill-amber-400" />
        ))}
      </div>

      {/* Vocabulary recap */}
      <div className="bg-card border border-border rounded-xl p-5 mb-5 text-left">
        <div className="flex items-center gap-2 mb-3">
          <Volume2 size={14} className="text-cyan-400" />
          <span className="data-label">Vocabulaire du scénario</span>
        </div>
        <div className="grid grid-cols-2 gap-2">
          {scenario.vocabulary.map((v, i) => (
            <div key={i} className="flex flex-col p-2 rounded-lg bg-muted/20 border border-border/40">
              <span className="text-sm font-mono font-medium text-foreground">{v.de}</span>
              <span className="text-xs text-muted-foreground">{v.fr}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Tips recap */}
      <div className="bg-card border border-border rounded-xl p-5 mb-6 text-left">
        <div className="flex items-center gap-2 mb-3">
          <BookOpen size={14} className="text-violet-400" />
          <span className="data-label">Conseils à retenir</span>
        </div>
        <ul className="space-y-1.5">
          {scenario.tips.map((tip, i) => (
            <li key={i} className="text-sm text-muted-foreground flex gap-2">
              <span className="text-violet-400 shrink-0">›</span>
              {tip}
            </li>
          ))}
        </ul>
      </div>

      {/* Actions */}
      <div className="flex gap-3 justify-center">
        <button
          onClick={onReplay}
          className="flex items-center gap-2 px-5 py-2.5 bg-card border border-border text-foreground rounded-lg text-sm font-medium hover:border-primary/50 transition-all"
        >
          <RotateCcw size={14} />
          Rejouer
        </button>
        <button
          onClick={onBack}
          className="flex items-center gap-2 px-5 py-2.5 bg-primary text-primary-foreground rounded-lg text-sm font-medium hover:opacity-90 transition-opacity"
        >
          <MessageSquare size={14} />
          Autre scénario
        </button>
      </div>
    </div>
  );
}

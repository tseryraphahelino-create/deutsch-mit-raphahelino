/**
 * Tests & Modèles — Goethe B2 Lesen
 * Port fidèle du MVP vanilla (lesen-teil1.html / lesen.css / lesen-teil1.js)
 * Palette "papier d'examen" scopée en inline-styles pour ne pas hériter du thème sombre.
 */

import { useState } from 'react';
import Layout from '@/components/Layout';

// ── Palette (miroir de lesen.css :root) ───────────────────────────────────
const P = {
  ink:        '#1d3557',
  inkLight:   '#457b9d',
  paper:      '#fdfcf9',
  paperAlt:   '#f4f1ea',
  border:     '#e2ddd1',
  text:       '#22262b',
  textMuted:  '#6b7280',
  success:    '#2a9d5c',
  successBg:  '#eaf7ef',
  error:      '#c0392b',
  errorBg:    '#fbeceb',
  radius:     '10px',
  shadow:     '0 2px 10px rgba(29,53,87,0.06)',
  fontDisplay: "'Georgia','Iowan Old Style',serif",
  fontBody:    "-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif",
};

// ── Types ─────────────────────────────────────────────────────────────────

interface SourceText {
  key: string;       // "a", "b", "c", "d"
  author?: string;
  content: string;
}

interface Question {
  id: number;
  statement: string;
  correctAnswer: string; // matches a sourceText key
}

interface ExerciseData {
  testId: string;
  teil: number;
  title: string;
  instructions: string;
  sourceTexts: SourceText[];
  questions: Question[];
}

// ── Données (format identique au JSON du zip) ─────────────────────────────

const EXERCISES: ExerciseData[] = [
  {
    testId: 'original-01',
    teil: 1,
    title: 'Lesen Teil 1 — Ehrenamtliches Engagement',
    instructions:
      'Lesen Sie die vier Kommentare (a–d) und die Aussagen (1–9). Ordnen Sie jeder Aussage den passenden Kommentar zu. Jeder Kommentar kann mehrmals verwendet werden.',
    sourceTexts: [
      {
        key: 'a',
        author: 'Lisa, 24, Studentin',
        content:
          'Seit einem Jahr helfe ich einmal wöchentlich bei der Tafel in meiner Stadt. Am Anfang wollte ich einfach nur etwas Sinnvolles tun, aber mittlerweile ist es fester Bestandteil meines Lebens geworden. Ich habe dort Menschen aus ganz unterschiedlichen Lebenssituationen kennengelernt, was meinen Blick auf die Gesellschaft stark verändert hat. Das größte Problem ist allerdings die Zeit: Zwischen Vorlesungen, Prüfungen und einem Nebenjob bleibt oft kaum Luft, und manchmal muss ich meine Schicht kurzfristig absagen, was mir ein schlechtes Gewissen bereitet.',
      },
      {
        key: 'b',
        author: 'Robert, 58, Ingenieur im Ruhestand',
        content:
          'Nach meiner Pensionierung wollte ich nicht einfach zu Hause sitzen, also gebe ich seit drei Jahren kostenlosen Mathe- und Physiknachhilfe für Kinder aus einkommensschwachen Familien. Es erfüllt mich, mein Wissen weiterzugeben und zu sehen, wie sich die Note eines Kindes verbessert. Was mich aber ärgert: Ehrenamtliche Arbeit wird in unserer Gesellschaft viel zu wenig anerkannt. Man hört ständig, wie wichtig Ehrenamt sei, aber echte Unterstützung, etwa durch bessere Räumlichkeiten oder steuerliche Erleichterungen, bleibt meistens aus.',
      },
      {
        key: 'c',
        author: 'Nadine, 33, Mutter von zwei Kindern',
        content:
          'Ich bin im Elternverein unserer Kindertagesstätte aktiv und organisiere zusammen mit anderen Eltern Feste und Spendenaktionen. Das lässt sich erstaunlich gut mit dem Familienalltag vereinbaren, solange man die Aufgaben flexibel einteilen kann und niemand auf feste Uhrzeiten besteht. Was mich allerdings wirklich stört, ist der bürokratische Aufwand: Für jede kleine Aktion müssen wir Formulare ausfüllen und Genehmigungen einholen, das nimmt oft mehr Zeit in Anspruch als die eigentliche Organisation der Veranstaltung selbst.',
      },
      {
        key: 'd',
        author: 'Kevin, 45, Feuerwehrmann',
        content:
          'Ich bin seit über zwanzig Jahren Mitglied der freiwilligen Feuerwehr in meinem Heimatdorf. Für kleine Gemeinden wie unsere ist das oft die einzige Möglichkeit, im Notfall überhaupt schnell Hilfe zu bekommen, denn die nächste Berufsfeuerwehr ist weit entfernt. Neben dem Zusammenhalt in der Mannschaft, den ich sehr schätze, motiviert mich vor allem das Gefühl, wirklich gebraucht zu werden. Sorgen bereitet mir jedoch, dass es immer schwieriger wird, junge Leute für die Ausbildung zu begeistern — viele ziehen wegen der Arbeit in die Stadt.',
      },
    ],
    questions: [
      { id: 1, statement: 'Diese Person hat gemerkt, dass ihr Engagement die eigene Sichtweise auf andere Menschen verändert hat.', correctAnswer: 'a' },
      { id: 2, statement: 'Diese Person findet, dass ehrenamtliche Arbeit von der Gesellschaft nicht ausreichend gewürdigt wird.', correctAnswer: 'b' },
      { id: 3, statement: 'Diese Person kann ihr Engagement gut mit dem Alltag vereinbaren, solange sie flexibel bleibt.', correctAnswer: 'c' },
      { id: 4, statement: 'Diese Person engagiert sich auch deshalb, weil in ihrer Umgebung sonst niemand schnell genug helfen könnte.', correctAnswer: 'd' },
      { id: 5, statement: 'Diese Person muss ihr Engagement manchmal wegen anderer Verpflichtungen kurzfristig absagen.', correctAnswer: 'a' },
      { id: 6, statement: 'Diese Person wünscht sich mehr konkrete Unterstützung, zum Beispiel finanzieller Art, für Ehrenamtliche.', correctAnswer: 'b' },
      { id: 7, statement: 'Diese Person ärgert sich über zu viel Papierkram bei der Organisation von Aktionen.', correctAnswer: 'c' },
      { id: 8, statement: 'Diese Person hat Schwierigkeiten, jüngere Menschen für ihre ehrenamtliche Tätigkeit zu gewinnen.', correctAnswer: 'd' },
      { id: 9, statement: 'Diese Person hat nach dem Ende ihres Berufslebens eine neue, sinnvolle Aufgabe gefunden.', correctAnswer: 'b' },
    ],
  },
  {
    testId: 'sample-01',
    teil: 1,
    title: 'Lesen Teil 1 — Homeoffice',
    instructions:
      'Lesen Sie die vier Kommentare (a–d) und die Aussagen (1–4). Ordnen Sie jeder Aussage den passenden Kommentar zu. Jeder Kommentar kann mehrmals verwendet werden.',
    sourceTexts: [
      {
        key: 'a',
        author: 'Julia, 29',
        content:
          'Seit ich im Homeoffice arbeite, spare ich jeden Tag über eine Stunde Fahrzeit. Allerdings vermisse ich den spontanen Austausch mit Kollegen in der Kaffeeküche sehr.',
      },
      {
        key: 'b',
        author: 'Markus, 41',
        content:
          'Ich finde Homeoffice grundsätzlich gut, aber nur an zwei oder drei Tagen pro Woche. Ganz ohne Büro fehlt mir die klare Trennung zwischen Arbeit und Freizeit.',
      },
      {
        key: 'c',
        author: 'Sabine, 35',
        content:
          'Für mich als Mutter von zwei kleinen Kindern ist Homeoffice ein Segen. Ich kann meine Arbeitszeiten viel flexibler an den Familienalltag anpassen.',
      },
      {
        key: 'd',
        author: 'Thomas, 52',
        content:
          'Nach über zwanzig Jahren im Büro fällt es mir schwer, mich zu Hause zu konzentrieren. Ich brauche die feste Struktur und die Kollegen um mich herum.',
      },
    ],
    questions: [
      { id: 1, statement: 'Diese Person profitiert vor allem dadurch, dass sie ihren Tagesablauf besser organisieren kann.', correctAnswer: 'c' },
      { id: 2, statement: 'Diese Person hat Schwierigkeiten, sich außerhalb des Büros zu fokussieren.', correctAnswer: 'd' },
      { id: 3, statement: 'Diese Person bevorzugt eine Mischung aus Büro- und Heimarbeit.', correctAnswer: 'b' },
      { id: 4, statement: 'Diese Person bedauert den fehlenden informellen Kontakt zu Kolleginnen und Kollegen.', correctAnswer: 'a' },
    ],
  },
];

// ── Composant principal ───────────────────────────────────────────────────

export default function Tests() {
  const [active, setActive] = useState<ExerciseData | null>(null);

  return (
    <Layout>
      {/* Wrapper qui réinitialise entièrement le thème sombre pour cette page */}
      <div
        style={{
          background: P.paperAlt,
          color: P.text,
          fontFamily: P.fontBody,
          minHeight: '100%',
          WebkitFontSmoothing: 'antialiased',
        }}
      >
        {active ? (
          <ExerciseView data={active} onBack={() => setActive(null)} />
        ) : (
          <TestList exercises={EXERCISES} onStart={setActive} />
        )}
      </div>
    </Layout>
  );
}

// ── Liste des exercices ────────────────────────────────────────────────────

function TestList({
  exercises,
  onStart,
}: {
  exercises: ExerciseData[];
  onStart: (e: ExerciseData) => void;
}) {
  return (
    <div style={{ maxWidth: 760, margin: '0 auto', padding: '2rem 1.25rem 4rem' }}>
      {/* En-tête */}
      <header
        style={{
          background: P.paper,
          border: `1px solid ${P.border}`,
          borderRadius: P.radius,
          padding: '1.75rem 1.75rem 1.5rem',
          marginBottom: '1.5rem',
          boxShadow: P.shadow,
        }}
      >
        <p
          style={{
            margin: '0 0 0.35rem',
            fontSize: '0.72rem',
            fontWeight: 700,
            letterSpacing: '0.08em',
            textTransform: 'uppercase',
            color: P.inkLight,
          }}
        >
          Goethe-Zertifikat B2
        </p>
        <h1
          style={{
            margin: '0 0 0.6rem',
            fontFamily: P.fontDisplay,
            fontSize: '1.9rem',
            color: P.ink,
          }}
        >
          Tests &amp; Modèles
        </h1>
        <p style={{ margin: 0, color: P.textMuted, fontSize: '0.95rem' }}>
          Simulations d'examens officiels avec correction automatique et score détaillé.
        </p>
      </header>

      {/* Cartes */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: '0.85rem' }}>
        {exercises.map(ex => (
          <button
            key={ex.testId}
            onClick={() => onStart(ex)}
            style={{
              display: 'block',
              width: '100%',
              textAlign: 'left',
              background: P.paper,
              border: `1.5px solid ${P.border}`,
              borderRadius: P.radius,
              padding: '1.25rem 1.5rem',
              boxShadow: P.shadow,
              cursor: 'pointer',
              transition: 'border-color 0.2s',
              fontFamily: P.fontBody,
            }}
            onMouseEnter={e => (e.currentTarget.style.borderColor = P.inkLight)}
            onMouseLeave={e => (e.currentTarget.style.borderColor = P.border)}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem', marginBottom: '0.5rem' }}>
              <span
                style={{
                  display: 'inline-flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  width: 26,
                  height: 26,
                  borderRadius: '50%',
                  background: P.ink,
                  color: '#fff',
                  fontWeight: 700,
                  fontSize: '0.75rem',
                }}
              >
                {ex.teil}
              </span>
              <span style={{ fontFamily: P.fontDisplay, fontWeight: 700, fontSize: '1.05rem', color: P.ink }}>
                {ex.title}
              </span>
            </div>
            <p style={{ margin: '0 0 0.5rem', fontSize: '0.9rem', color: P.textMuted, lineHeight: 1.5 }}>
              {ex.instructions}
            </p>
            <span
              style={{
                display: 'inline-block',
                marginTop: '0.25rem',
                fontSize: '0.8rem',
                fontWeight: 600,
                color: P.inkLight,
              }}
            >
              {ex.questions.length} questions — Commencer →
            </span>
          </button>
        ))}
      </div>
    </div>
  );
}

// ── Vue exercice (port fidèle du HTML/JS du zip) ──────────────────────────

type CorrectionMap = Record<number, 'correct' | 'incorrect'>;

function ExerciseView({ data, onBack }: { data: ExerciseData; onBack: () => void }) {
  const optionKeys = data.sourceTexts.map(t => t.key);

  // answers: questionId → chosen key
  const [answers, setAnswers] = useState<Record<number, string>>({});
  const [corrected, setCorrected] = useState(false);
  const [correction, setCorrection] = useState<CorrectionMap>({});
  const [score, setScore] = useState<{ correct: number; total: number } | null>(null);

  function handleSelect(questionId: number, key: string) {
    if (corrected) return;
    setAnswers(prev => ({ ...prev, [questionId]: key }));
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (corrected) return;

    const map: CorrectionMap = {};
    let correct = 0;

    data.questions.forEach(q => {
      const userAns = answers[q.id] ?? null;
      const ok = userAns === q.correctAnswer;
      if (ok) correct++;
      map[q.id] = ok ? 'correct' : 'incorrect';
    });

    setCorrection(map);
    setScore({ correct, total: data.questions.length });
    setCorrected(true);
  }

  function handleReset() {
    setAnswers({});
    setCorrection({});
    setScore(null);
    setCorrected(false);
  }

  const pct = score ? Math.round((score.correct / score.total) * 100) : 0;

  let resultMessage = '';
  if (score) {
    if (pct === 100) resultMessage = 'Perfekt! Alle Antworten sind richtig. 🎉';
    else if (pct >= 70) resultMessage = 'Sehr gut! Du bist auf dem richtigen Weg zum Goethe-Zertifikat B2.';
    else if (pct >= 50) resultMessage = 'Nicht schlecht — sieh dir die markierten Fragen noch einmal an.';
    else resultMessage = 'Übung macht den Meister — wiederhole die falschen Antworten und versuche es erneut.';
  }

  return (
    <div style={{ maxWidth: 760, margin: '0 auto', padding: '2rem 1.25rem 4rem' }}>
      {/* Bouton retour */}
      <button
        onClick={onBack}
        style={{
          background: 'none',
          border: 'none',
          cursor: 'pointer',
          color: P.inkLight,
          fontSize: '0.85rem',
          fontWeight: 600,
          marginBottom: '1.25rem',
          padding: 0,
          fontFamily: P.fontBody,
        }}
      >
        ← Retour aux exercices
      </button>

      {/* En-tête exercice */}
      <header
        style={{
          background: P.paper,
          border: `1px solid ${P.border}`,
          borderRadius: P.radius,
          padding: '1.75rem 1.75rem 1.5rem',
          marginBottom: '1.5rem',
          boxShadow: P.shadow,
        }}
      >
        <p
          style={{
            margin: '0 0 0.35rem',
            fontSize: '0.72rem',
            fontWeight: 700,
            letterSpacing: '0.08em',
            textTransform: 'uppercase',
            color: P.inkLight,
          }}
        >
          Goethe-Zertifikat B2
        </p>
        <h1
          style={{
            margin: '0 0 0.6rem',
            fontFamily: P.fontDisplay,
            fontSize: '1.9rem',
            color: P.ink,
          }}
        >
          {data.title}
        </h1>
        <p style={{ margin: 0, color: P.textMuted, fontSize: '0.95rem' }}>{data.instructions}</p>
      </header>

      {/* Textes source (a, b, c, d) */}
      <section
        aria-label="Kommentare"
        style={{
          display: 'grid',
          gridTemplateColumns: '1fr 1fr',
          gap: '0.9rem',
          marginBottom: '1.75rem',
        }}
      >
        {data.sourceTexts.map(src => (
          <article
            key={src.key}
            style={{
              background: P.paper,
              border: `1px solid ${P.border}`,
              borderRadius: P.radius,
              padding: '1rem 1.1rem',
              boxShadow: P.shadow,
            }}
          >
            <span
              style={{
                display: 'inline-flex',
                alignItems: 'center',
                justifyContent: 'center',
                width: 26,
                height: 26,
                borderRadius: '50%',
                background: P.ink,
                color: '#fff',
                fontWeight: 700,
                fontSize: '0.85rem',
                marginBottom: '0.5rem',
              }}
            >
              {src.key}
            </span>
            {src.author && (
              <p
                style={{
                  margin: '0 0 0.3rem',
                  fontSize: '0.78rem',
                  fontWeight: 600,
                  color: P.inkLight,
                }}
              >
                {src.author}
              </p>
            )}
            <p style={{ margin: 0, fontSize: '0.9rem', color: P.text }}>{src.content}</p>
          </article>
        ))}
      </section>

      {/* Formulaire questions */}
      <form onSubmit={handleSubmit}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.85rem' }}>
          {data.questions.map(q => {
            const state = correction[q.id];
            const isCorrect = state === 'correct';
            const isIncorrect = state === 'incorrect';

            let cardBg = P.paper;
            let cardBorder = P.border;
            if (isCorrect)   { cardBg = P.successBg; cardBorder = P.success; }
            if (isIncorrect) { cardBg = P.errorBg;   cardBorder = P.error;   }

            return (
              <div
                key={q.id}
                style={{
                  background: cardBg,
                  border: `1px solid ${cardBorder}`,
                  borderRadius: P.radius,
                  padding: '1.1rem 1.25rem',
                  boxShadow: P.shadow,
                  transition: 'border-color 0.2s, background 0.2s',
                }}
              >
                {/* Énoncé */}
                <div
                  style={{
                    display: 'flex',
                    gap: '0.6rem',
                    fontSize: '0.95rem',
                    marginBottom: '0.75rem',
                    color: P.text,
                  }}
                >
                  <span style={{ flexShrink: 0, fontWeight: 700, color: P.ink }}>{q.id}.</span>
                  <span>{q.statement}</span>
                </div>

                {/* Pills de réponse */}
                <div
                  role="radiogroup"
                  aria-label={`Frage ${q.id}`}
                  style={{ display: 'flex', flexWrap: 'wrap', gap: '0.5rem' }}
                >
                  {optionKeys.map(key => {
                    const isSelected = answers[q.id] === key;

                    let pillBg = 'transparent';
                    let pillBorder = P.border;
                    let pillColor = P.text;

                    if (isSelected) {
                      pillBg     = P.ink;
                      pillBorder = P.ink;
                      pillColor  = '#fff';
                    }
                    if (corrected && isSelected && isCorrect) {
                      pillBg = P.success; pillBorder = P.success;
                    }
                    if (corrected && isSelected && isIncorrect) {
                      pillBg = P.error; pillBorder = P.error;
                    }

                    return (
                      <label
                        key={key}
                        style={{
                          display: 'inline-flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          minWidth: 42,
                          padding: '0.4rem 0.7rem',
                          border: `1.5px solid ${pillBorder}`,
                          borderRadius: 8,
                          fontWeight: 600,
                          fontSize: '0.9rem',
                          color: pillColor,
                          background: pillBg,
                          cursor: corrected ? 'default' : 'pointer',
                          transition: 'all 0.15s ease',
                          userSelect: 'none',
                        }}
                      >
                        <input
                          type="radio"
                          name={`question-${q.id}`}
                          value={key}
                          checked={answers[q.id] === key}
                          onChange={() => handleSelect(q.id, key)}
                          disabled={corrected}
                          style={{ position: 'absolute', opacity: 0, width: 0, height: 0 }}
                        />
                        {key}
                      </label>
                    );
                  })}
                </div>

                {/* Indice si mauvaise réponse */}
                {corrected && isIncorrect && (
                  <p
                    style={{
                      marginTop: '0.5rem',
                      fontSize: '0.82rem',
                      color: P.success,
                      fontWeight: 600,
                    }}
                  >
                    {answers[q.id]
                      ? `Bonne réponse : ${q.correctAnswer}`
                      : `Pas de réponse — bonne réponse : ${q.correctAnswer}`}
                  </p>
                )}
              </div>
            );
          })}
        </div>

        {/* Boutons d'action */}
        <div style={{ display: 'flex', gap: '0.75rem', marginTop: '1.5rem' }}>
          {!corrected && (
            <button
              type="submit"
              style={{
                border: 'none',
                borderRadius: 8,
                padding: '0.75rem 1.6rem',
                fontSize: '0.95rem',
                fontWeight: 600,
                cursor: 'pointer',
                background: P.ink,
                color: '#fff',
                fontFamily: P.fontBody,
                transition: 'opacity 0.15s',
              }}
              onMouseEnter={e => (e.currentTarget.style.opacity = '0.88')}
              onMouseLeave={e => (e.currentTarget.style.opacity = '1')}
            >
              Valider
            </button>
          )}
          {corrected && (
            <button
              type="button"
              onClick={handleReset}
              style={{
                border: `1.5px solid ${P.border}`,
                borderRadius: 8,
                padding: '0.75rem 1.6rem',
                fontSize: '0.95rem',
                fontWeight: 600,
                cursor: 'pointer',
                background: 'transparent',
                color: P.ink,
                fontFamily: P.fontBody,
                transition: 'background 0.15s',
              }}
              onMouseEnter={e => (e.currentTarget.style.background = P.paper)}
              onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}
            >
              Recommencer
            </button>
          )}
        </div>
      </form>

      {/* Résultat final */}
      {score && (
        <section
          style={{
            marginTop: '1.75rem',
            background: P.paper,
            border: `1px solid ${P.border}`,
            borderLeft: `5px solid ${P.ink}`,
            borderRadius: P.radius,
            padding: '1.5rem 1.75rem',
            boxShadow: P.shadow,
          }}
        >
          <h2
            style={{
              margin: '0 0 0.4rem',
              fontFamily: P.fontDisplay,
              color: P.ink,
              fontSize: '1.4rem',
            }}
          >
            {score.correct} / {score.total} points ({pct}%)
          </h2>
          <p style={{ margin: 0, color: P.textMuted }}>{resultMessage}</p>
        </section>
      )}
    </div>
  );
}

import { useLearn } from '@/contexts/LearnContext';
import { LESSONS } from '@/contexts/LearnContext';

const MOTIVATIONAL = [
  'Übung macht den Meister — C\'est en forgeant qu\'on devient forgeron.',
  'Schritt für Schritt — Pas à pas.',
  'Wer nicht wagt, der nicht gewinnt — Qui ne risque rien n\'a rien.',
  'Sprachen öffnen Türen — Les langues ouvrent des portes.',
  'Heute lernen, morgen sprechen — Apprenez aujourd\'hui, parlez demain.',
];

export default function StatusBand() {
  const { progress } = useLearn();
  const completed = Object.values(progress).filter(p => p.completed).length;
  const total = LESSONS.length;
  const pct = total > 0 ? Math.round((completed / total) * 100) : 0;
  const quote = MOTIVATIONAL[new Date().getDay() % MOTIVATIONAL.length];

  return (
    <div className="border-b border-border bg-card/50 backdrop-blur-sm px-4 py-2 flex items-center gap-4 text-xs overflow-hidden">
      <div className="flex items-center gap-2 shrink-0">
        <span className="data-label">Progression</span>
        <div className="w-24 h-1.5 bg-muted rounded-full overflow-hidden">
          <div
            className="h-full bg-primary rounded-full transition-all duration-700"
            style={{ width: `${pct}%` }}
          />
        </div>
        <span className="font-mono text-primary">{completed}/{total}</span>
      </div>
      <div className="hidden md:block h-3 w-px bg-border shrink-0" />
      <p className="hidden md:block text-muted-foreground truncate italic">{quote}</p>
    </div>
  );
}

/*
 * Layout: Akademisch Futuristisch
 * Dark navy background, cyan/amber accents, Space Grotesk headings
 */
import { Link, useLocation } from 'wouter';
import { BookOpen, Brain, GraduationCap, Menu, X, Home, PenLine, ClipboardList } from 'lucide-react';
import { useState } from 'react';
import { LEVEL_NAMES, type LevelId } from '@/contexts/LearnContext';
import { useLearn } from '@/contexts/LearnContext';
import StatusBand from '@/components/StatusBand';

const levels: LevelId[] = ['A1', 'A2', 'B1', 'B2', 'C1', 'C2'];

const navItems = [
  { href: '/', label: 'Accueil', icon: Home },
  { href: '/lecons', label: 'Leçons', icon: BookOpen },
  { href: '/exercices', label: 'Exercices', icon: Brain },
  { href: '/ia', label: 'Pratique IA', icon: GraduationCap },
  { href: '/ecriture', label: 'Écriture', icon: PenLine },
  { href: '/tests', label: 'Tests', icon: ClipboardList },
];

// Simple logo mark (replaces missing external image)
function LogoMark({ size = 36 }: { size?: number }) {
  return (
    <div
      className="rounded-lg bg-primary/20 border border-primary/40 flex items-center justify-center shrink-0 font-display font-bold text-primary"
      style={{ width: size, height: size, fontSize: size * 0.38 }}
    >
      DR
    </div>
  );
}

export default function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);
  const { getLevelProgress } = useLearn();

  const levelColors: Record<LevelId, string> = {
    A1: 'bg-emerald-400', A2: 'bg-blue-400', B1: 'bg-cyan-400',
    B2: 'bg-amber-400', C1: 'bg-violet-400', C2: 'bg-rose-400',
  };
  const levelTextColors: Record<LevelId, string> = {
    A1: 'text-emerald-400', A2: 'text-blue-400', B1: 'text-cyan-400',
    B2: 'text-amber-400', C1: 'text-violet-400', C2: 'text-rose-400',
  };

  return (
    <div className="min-h-screen flex">
      {/* Sidebar - Desktop */}
      <aside className="hidden lg:flex flex-col w-64 bg-sidebar border-r border-sidebar-border fixed h-screen overflow-y-auto z-40">
        {/* Logo */}
        <div className="p-5 border-b border-sidebar-border">
          <Link href="/">
            <div className="flex items-center gap-3 group cursor-pointer">
              <LogoMark size={36} />
              <div>
                <h1 className="font-display font-bold text-base text-foreground group-hover:text-primary transition-colors">
                  Deutsch mit R.
                </h1>
                <p className="text-[10px] text-muted-foreground font-mono">v2.0 // A1–C2</p>
              </div>
            </div>
          </Link>
        </div>

        {/* Nav */}
        <nav className="p-3 space-y-1 flex-1">
          {navItems.map(item => {
            const isActive = location === item.href || (item.href !== '/' && location.startsWith(item.href));
            return (
              <Link key={item.href} href={item.href}>
                <div className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-200 cursor-pointer ${
                  isActive
                    ? 'bg-primary/15 text-primary'
                    : 'text-muted-foreground hover:bg-accent/10 hover:text-foreground'
                }`}>
                  <item.icon size={18} />
                  <span>{item.label}</span>
                </div>
              </Link>
            );
          })}
        </nav>

        {/* Levels Progress */}
        <div className="p-4 border-t border-sidebar-border">
          <p className="text-[11px] uppercase tracking-wider text-muted-foreground mb-3 font-display font-semibold">
            Niveaux CEFR
          </p>
          <div className="space-y-2">
            {levels.map(level => {
              const prog = getLevelProgress(level);
              return (
                <div key={level} className="flex items-center gap-2">
                  <span className={`text-[11px] font-mono font-bold w-7 ${levelTextColors[level]}`}>{level}</span>
                  <div className="flex-1 h-1.5 bg-muted rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all duration-700 ${levelColors[level]}`}
                      style={{ width: `${prog.percentage}%` }}
                    />
                  </div>
                  <span className="text-[10px] text-muted-foreground w-8 text-right">{prog.percentage}%</span>
                </div>
              );
            })}
          </div>
        </div>
      </aside>

      {/* Mobile Header */}
      <div className="lg:hidden fixed top-0 left-0 right-0 z-50 bg-background/90 backdrop-blur-xl border-b border-border">
        <div className="flex items-center justify-between px-4 py-3">
          <Link href="/">
            <div className="flex items-center gap-2 cursor-pointer">
              <LogoMark size={32} />
              <span className="font-display font-bold text-sm">Deutsch mit R.</span>
            </div>
          </Link>
          <button
            onClick={() => setMobileOpen(!mobileOpen)}
            className="p-2 rounded-lg hover:bg-accent/10 transition-colors"
          >
            {mobileOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>

        {/* Mobile Nav */}
        {mobileOpen && (
          <div className="px-4 pb-4 bg-background/95 backdrop-blur-xl">
            <nav className="space-y-1">
              {navItems.map(item => {
                const isActive = location === item.href || (item.href !== '/' && location.startsWith(item.href));
                return (
                  <Link key={item.href} href={item.href}>
                    <div
                      onClick={() => setMobileOpen(false)}
                      className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all cursor-pointer ${
                        isActive ? 'bg-primary/15 text-primary' : 'text-muted-foreground hover:bg-accent/10'
                      }`}
                    >
                      <item.icon size={18} />
                      <span>{item.label}</span>
                    </div>
                  </Link>
                );
              })}
            </nav>
            <div className="mt-4 pt-4 border-t border-border">
              <div className="space-y-1.5">
                {levels.map(level => {
                  const prog = getLevelProgress(level);
                  return (
                    <div key={level} className="flex items-center gap-2">
                      <span className={`text-[10px] font-mono font-bold w-6 ${levelTextColors[level]}`}>{level}</span>
                      <div className="flex-1 h-1 bg-muted rounded-full overflow-hidden">
                        <div className={`h-full rounded-full ${levelColors[level]}`} style={{ width: `${prog.percentage}%` }} />
                      </div>
                      <span className="text-[9px] text-muted-foreground">{prog.percentage}%</span>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Main Content */}
      <main className="flex-1 lg:ml-64 pt-14 lg:pt-0">
        <StatusBand />
        {children}
      </main>
    </div>
  );
}

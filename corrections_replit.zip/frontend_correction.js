```javascript
// Supposons que c'est le code JavaScript qui gère l'envoi du texte et la réception de la correction.

const textarea = document.getElementById('your-textarea-id'); // Remplacez par l'ID réel de votre textarea
const charCountDisplay = document.getElementById('char-count-display-id'); // Remplacez par l'ID réel de l'affichage du compteur
const errorMessageDisplay = document.getElementById('error-message-display-id'); // Remplacez par l'ID réel de l'affichage des erreurs
const correctButton = document.getElementById('correct-button-id'); // Remplacez par l'ID réel de votre bouton de correction

const MAX_CHARS = 10000; // Nouvelle limite de caractères

// Fonction pour mettre à jour le compteur de caractères
function updateCharCount() {
    const currentLength = textarea.value.length;
    charCountDisplay.textContent = `${currentLength} / ${MAX_CHARS} caractères`;
    if (currentLength > MAX_CHARS) {
        charCountDisplay.style.color = 'red';
        correctButton.disabled = true;
    } else {
        charCountDisplay.style.color = ''; // Réinitialiser la couleur
        correctButton.disabled = false;
    }
}

// Écouteur d'événements pour la saisie dans la textarea
if (textarea) {
    textarea.addEventListener('input', updateCharCount);
    updateCharCount(); // Initialiser le compteur au chargement
}

// Fonction pour envoyer le texte à corriger
async function sendTextForCorrection() {
    if (errorMessageDisplay) {
        errorMessageDisplay.textContent = ''; // Effacer les messages d'erreur précédents
        errorMessageDisplay.style.display = 'none';
    }

    const textToCorrect = textarea.value;

    if (textToCorrect.length < 20 || textToCorrect.length > MAX_CHARS) {
        if (errorMessageDisplay) {
            errorMessageDisplay.textContent = `Veuillez écrire entre 20 et ${MAX_CHARS} caractères.`;
            errorMessageDisplay.style.display = 'block';
        }
        return;
    }

    try {
        const response = await fetch('/api/correct-text', { // Remplacez par l'URL réelle de votre API
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ text: textToCorrect }),
        });

        // Vérifier si la réponse est OK (statut 2xx)
        if (!response.ok) {
            let errorData = `Erreur HTTP: ${response.status} ${response.statusText}`;
            const contentType = response.headers.get('content-type');

            if (contentType && contentType.includes('application/json')) {
                const jsonError = await response.json();
                errorData = jsonError.message || JSON.stringify(jsonError);
            } else {
                // Si ce n'est pas du JSON, c'est probablement du HTML ou du texte brut
                const textError = await response.text();
                errorData = `Erreur du serveur (non-JSON) : ${textError.substring(0, 200)}...`; // Limiter la taille pour l'affichage
            }
            throw new Error(errorData);
        }

        const data = await response.json();

        // Traiter la réponse JSON (par exemple, afficher la correction)
        console.log('Correction reçue :', data);
        // Exemple: displayCorrection(data.correctedText);

    } catch (error) {
        console.error('Erreur lors de la correction :', error);
        if (errorMessageDisplay) {
            errorMessageDisplay.textContent = `Une erreur est survenue : ${error.message}`;
            errorMessageDisplay.style.display = 'block';
        }
    }
}

// Attacher la fonction à votre bouton de correction
if (correctButton) {
    correctButton.addEventListener('click', sendTextForCorrection);
}
```

**Explication des modifications :**

1.  **`MAX_CHARS = 10000;`**: La limite de caractères est augmentée à 10 000. Le compteur de caractères et la validation côté client seront mis à jour en conséquence.
2.  **Gestion des erreurs de réponse (`if (!response.ok)`)** :
    *   Avant de tenter de parser la réponse en JSON, nous vérifions `response.ok` pour s'assurer que la requête HTTP a réussi (statut 2xx).
    *   Nous vérifions également l'en-tête `Content-Type` de la réponse. Si c'est du JSON, nous essayons de le parser. Sinon, nous lisons la réponse comme du texte brut (ce qui est le cas de votre erreur `<!DOCTYPE html>`).
    *   Cela permet d'afficher un message d'erreur plus clair à l'utilisateur, au lieu de l'erreur JSON non valide.
3.  **Affichage des erreurs (`errorMessageDisplay`)** : Un élément HTML (que vous devrez ajouter) est utilisé pour afficher les messages d'erreur à l'utilisateur.
4.  **Mise à jour du compteur de caractères (`updateCharCount`)** : Le compteur est mis à jour pour refléter la nouvelle limite et désactiver le bouton si le texte est trop long.

**Pour implémenter ce code :**

1.  **Ajoutez les IDs** (`your-textarea-id`, `char-count-display-id`, `error-message-display-id`, `correct-button-id`) aux éléments HTML correspondants dans votre page.
2.  **Remplacez `/api/correct-text`** par l'URL réelle de votre endpoint API de correction.
3.  **Intégrez ce JavaScript** dans votre projet (par exemple, dans un fichier `.js` lié à votre HTML).

---
